# Experiment results (300 games per match-up, first player alternates)

| Agent A | Agent B | A wins | B wins | Draws | A win % | Avg moves/game | A ms/move | B ms/move |
|---|---|---|---|---|---|---|---|---|
| Greedy (depth 1) | Random | 288 | 12 | 0 | 96.0% | 12.9 | 1.0 | 0.0 |
| Expectiminimax d2 | Random | 294 | 6 | 0 | 98.0% | 13.5 | 7.5 | 0.0 |
| Expectiminimax d2 | Greedy (depth 1) | 186 | 112 | 2 | 62.0% | 17.8 | 7.0 | 1.1 |
| Expectiminimax d4 | Greedy (depth 1) | 203 | 95 | 2 | 67.7% | 16.3 | 215.0 | 1.1 |
| Expectiminimax d4 | Expectiminimax d2 | 159 | 131 | 10 | 53.0% | 21.8 | 188.8 | 6.5 |
| Expectiminimax d4 | Minimax d4 (ignores dice) | 144 | 145 | 11 | 48.0% | 21.8 | 192.7 | 73.0 |

# Search effort per move

| Depth | Position | Positions searched | Time (ms) |
|---|---|---|---|
| 1 | empty board | 19 | 0.9 |
| 1 | mid-game | 19 | 0.9 |
| 2 | empty board | 152 | 5.7 |
| 2 | mid-game | 152 | 3.5 |
| 3 | empty board | 1,083 | 27.5 |
| 3 | mid-game | 1,078 | 35.3 |
| 4 | empty board | 5,605 | 162.6 |
| 4 | mid-game | 5,377 | 142.9 |
| 5 | empty board | 26,885 | 642.5 |
| 5 | mid-game | 25,052 | 653.6 |

# Does modelling the dice change the move?

Expectiminimax d4 and Minimax d4 (ignores dice) chose the same column in 743 of 1200 positions (61.9%).
