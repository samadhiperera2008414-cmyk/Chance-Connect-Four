# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  config.py
#  Central place for the student details and the tunable settings of the
#  game, so they only ever need to be changed in one file.
# =====================================================================

# ---- Student details (shown on the title screen and in the game header) ----
STUDENT_NAME = "Samadhi Perera"
STUDENT_ID = "9239EXJP"

GAME_TITLE = "Chance Connect Four"

# ---- Links (fill these in after publishing - used by the slides and report) ----
PUBLISHED_URL = "https://samadhiperera2008414-cmyk.itch.io/chanceconnectfour"
REPO_URL = "https://github.com/samadhiperera2008414-cmyk/chance-connect-four"

# ---- AI difficulty = how many plies (move + dice roll) the AI looks ahead ----
DIFFICULTY_DEPTHS = {
    "Easy": 1,     # only looks at its own move (greedy)
    "Medium": 2,   # its move + the opponent's reply
    "Hard": 4,     # its move + reply + its next move + the next reply
}

# ---- Window size in pixels ----
WINDOW_WIDTH = 960
WINDOW_HEIGHT = 720
FRAMES_PER_SECOND = 60
