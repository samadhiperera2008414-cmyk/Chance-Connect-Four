# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  board.py
#  The rules of the game, kept separate from the graphics and the AI.
#
#  Rules
#  -----
#  * Two players take turns choosing one of 7 columns on a 6 x 7 grid.
#  * After choosing, the player rolls the WIND DIE (a normal six-sided die):
#        1      -> a gust blows the piece ONE column LEFT
#        2 - 5  -> calm, the piece lands in the column that was aimed at
#        6      -> a gust blows the piece ONE column RIGHT
#  * If the gust would push the piece off the board or into a full column,
#    the piece lands in the aimed column instead.
#  * First player to connect 4 pieces in a row (horizontal, vertical or
#    diagonal) wins. A full board with no winner is a draw.
#  * Because of the wind, a piece can even land somewhere that completes
#    a line by luck - this is the "chance" element required by the brief.
# =====================================================================

import random

# ---- Board dimensions and cell values ----
ROWS = 6
COLS = 7
WIN_LENGTH = 4

EMPTY = 0
PLAYER_ONE = 1
PLAYER_TWO = 2

# ---- Wind die: maps a die face to a column shift ----
DIE_FACE_TO_DRIFT = {1: -1, 2: 0, 3: 0, 4: 0, 5: 0, 6: +1}

# ---- Probability of each column shift (derived from the die above) ----
DRIFT_PROBABILITIES = {-1: 1 / 6, 0: 4 / 6, +1: 1 / 6}


# ---------------------------------------------------------------------
# create_board
# Builds a new, empty game board.
# Parameters: none
# Returns: a list of ROWS lists, each holding COLS cells set to EMPTY.
#          Row 0 is the TOP of the board, row ROWS-1 is the bottom.
# ---------------------------------------------------------------------
def create_board():
    return [[EMPTY for _ in range(COLS)] for _ in range(ROWS)]


# ---------------------------------------------------------------------
# copy_board
# Makes an independent copy of a board so it can be changed safely.
# Parameters:
#   board - the 2D list to copy
# Returns: a new 2D list with the same contents
# ---------------------------------------------------------------------
def copy_board(board):
    return [row[:] for row in board]


# ---------------------------------------------------------------------
# get_other_player
# Gives the opponent of a player.
# Parameters:
#   player - PLAYER_ONE or PLAYER_TWO
# Returns: the other player's number
# ---------------------------------------------------------------------
def get_other_player(player):
    return PLAYER_TWO if player == PLAYER_ONE else PLAYER_ONE


# ---------------------------------------------------------------------
# is_valid_column
# Checks whether a piece can be dropped into a column.
# Parameters:
#   board  - the current 2D board
#   column - column index to test (may be out of range)
# Returns: True if the column exists and its top cell is still empty
# ---------------------------------------------------------------------
def is_valid_column(board, column):
    return 0 <= column < COLS and board[0][column] == EMPTY


# ---------------------------------------------------------------------
# get_valid_columns
# Lists every column that still has space.
# Parameters:
#   board - the current 2D board
# Returns: a list of column indexes, left to right
# ---------------------------------------------------------------------
def get_valid_columns(board):
    return [column for column in range(COLS) if is_valid_column(board, column)]


# ---------------------------------------------------------------------
# get_landing_row
# Finds the row a piece would fall to in a column.
# Parameters:
#   board  - the current 2D board
#   column - the column the piece is dropped into
# Returns: the lowest empty row index, or -1 if the column is full
# ---------------------------------------------------------------------
def get_landing_row(board, column):
    for row in range(ROWS - 1, -1, -1):
        if board[row][column] == EMPTY:
            return row
    return -1


# ---------------------------------------------------------------------
# roll_wind_die
# Rolls the six-sided wind die.
# Parameters:
#   rng - a random.Random object (lets tests and experiments use a seed)
# Returns: an integer from 1 to 6
# ---------------------------------------------------------------------
def roll_wind_die(rng=random):
    return rng.randint(1, 6)


# ---------------------------------------------------------------------
# resolve_landing_column
# Works out which column a piece really lands in after the wind.
# Parameters:
#   board      - the current 2D board
#   aimed      - the column the player chose
#   drift      - column shift caused by the wind (-1, 0 or +1)
# Returns: the column the piece ends up in. If the shifted column is off
#          the board or full, the piece stays in the aimed column.
# ---------------------------------------------------------------------
def resolve_landing_column(board, aimed, drift):
    target = aimed + drift
    if is_valid_column(board, target):
        return target
    return aimed


# ---------------------------------------------------------------------
# get_chance_outcomes
# Lists every column a piece aimed at `aimed` could land in, with the
# probability of each. Outcomes that lead to the same column are merged,
# so the probabilities always add up to 1. This is what the AI uses for
# its CHANCE nodes.
# Parameters:
#   board - the current 2D board
#   aimed - the column the player chose (must be a valid column)
# Returns: a list of (landing_column, probability) tuples
# ---------------------------------------------------------------------
def get_chance_outcomes(board, aimed):
    merged = {}
    for drift, probability in DRIFT_PROBABILITIES.items():
        landing = resolve_landing_column(board, aimed, drift)
        merged[landing] = merged.get(landing, 0.0) + probability
    return sorted(merged.items())


# ---------------------------------------------------------------------
# drop_piece
# Places a piece in the lowest empty cell of a column (changes the board).
# Parameters:
#   board  - the 2D board to change
#   column - the column to drop into
#   player - the player who owns the piece
# Returns: the row the piece landed in, or -1 if the column was full
# ---------------------------------------------------------------------
def drop_piece(board, column, player):
    row = get_landing_row(board, column)
    if row != -1:
        board[row][column] = player
    return row


# ---------------------------------------------------------------------
# remove_piece
# Undoes a drop by clearing one cell. Used by the AI search so it can
# try a move and then take it back without copying the whole board.
# Parameters:
#   board  - the 2D board to change
#   row    - row of the cell to clear
#   column - column of the cell to clear
# Returns: nothing
# ---------------------------------------------------------------------
def remove_piece(board, row, column):
    board[row][column] = EMPTY


# ---------------------------------------------------------------------
# count_in_direction
# Counts how many of a player's pieces are in a straight line starting
# next to a cell and moving in one direction.
# Parameters:
#   board        - the current 2D board
#   row, column  - the starting cell (not counted itself)
#   row_step     - row change per step (-1, 0 or 1)
#   column_step  - column change per step (-1, 0 or 1)
#   player       - whose pieces to count
# Returns: the number of consecutive matching pieces
# ---------------------------------------------------------------------
def count_in_direction(board, row, column, row_step, column_step, player):
    count = 0
    r, c = row + row_step, column + column_step
    while 0 <= r < ROWS and 0 <= c < COLS and board[r][c] == player:
        count += 1
        r += row_step
        c += column_step
    return count


# ---------------------------------------------------------------------
# is_winning_placement
# Fast win check: looks only at the lines through the piece just placed.
# Parameters:
#   board        - the board AFTER the piece has been placed
#   row, column  - where the piece was placed
#   player       - the player who placed it
# Returns: True if that piece completes 4 (or more) in a row
# ---------------------------------------------------------------------
def is_winning_placement(board, row, column, player):
    # The four line directions: horizontal, vertical, two diagonals
    for row_step, column_step in ((0, 1), (1, 0), (1, 1), (1, -1)):
        total = 1
        total += count_in_direction(board, row, column, row_step, column_step, player)
        total += count_in_direction(board, row, column, -row_step, -column_step, player)
        if total >= WIN_LENGTH:
            return True
    return False


# ---------------------------------------------------------------------
# get_winning_cells
# Full-board scan for a winning line (used to highlight it on screen).
# Parameters:
#   board  - the current 2D board
#   player - the player to check
# Returns: a list of 4 (row, column) cells forming a line, or [] if none
# ---------------------------------------------------------------------
def get_winning_cells(board, player):
    for row in range(ROWS):
        for column in range(COLS):
            for row_step, column_step in ((0, 1), (1, 0), (1, 1), (1, -1)):
                cells = []
                for i in range(WIN_LENGTH):
                    r, c = row + i * row_step, column + i * column_step
                    if not (0 <= r < ROWS and 0 <= c < COLS) or board[r][c] != player:
                        break
                    cells.append((r, c))
                if len(cells) == WIN_LENGTH:
                    return cells
    return []


# ---------------------------------------------------------------------
# is_board_full
# Checks for a draw position (no empty cells left).
# Parameters:
#   board - the current 2D board
# Returns: True if every column is full
# ---------------------------------------------------------------------
def is_board_full(board):
    return all(board[0][column] != EMPTY for column in range(COLS))


# ---------------------------------------------------------------------
# board_to_text
# Turns a board into readable text (used for the console, tests and the
# "sample input / output" section of the report).
# Parameters:
#   board - the 2D board to print
# Returns: a multi-line string, X = player one, O = player two
# ---------------------------------------------------------------------
def board_to_text(board):
    symbols = {EMPTY: ".", PLAYER_ONE: "X", PLAYER_TWO: "O"}
    lines = [" ".join(symbols[cell] for cell in row) for row in board]
    lines.append(" ".join(str(column + 1) for column in range(COLS)))
    return "\n".join(lines)
