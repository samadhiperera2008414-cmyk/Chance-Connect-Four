# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  ai.py
#  The computer opponent. It uses EXPECTIMINIMAX search:
#
#    MAX node    - the AI's turn: pick the column with the HIGHEST value
#    MIN node    - the opponent's turn: assume they pick the LOWEST value
#    CHANCE node - the wind die: the value is the probability-weighted
#                  AVERAGE of every place the piece could land
#
#  The tree alternates  MAX -> CHANCE -> MIN -> CHANCE -> MAX ...
#  At each turn the AI evaluates all possible consequences of every move
#  (every column x every wind outcome x every reply ...) down to a fixed
#  depth, then chooses the move whose expected value is closest to victory.
#  Positions at the depth limit are scored with a heuristic function.
# =====================================================================

import random
import time

import board as rules

# ---- Score given to a win. Much larger than any heuristic score. ----
WIN_SCORE = 100000

# ---- Heuristic weights (per 4-cell window and per centre piece) ----
THREE_IN_WINDOW = 5     # 3 own pieces + 1 empty cell in a window of 4
TWO_IN_WINDOW = 2       # 2 own pieces + 2 empty cells
CENTRE_PIECE = 3        # each piece in the centre column

# ---- Columns tried centre-first so ties favour the centre ----
CENTRE_FIRST_ORDER = sorted(range(rules.COLS), key=lambda c: abs(c - rules.COLS // 2))


# ---------------------------------------------------------------------
# build_all_windows
# Pre-computes every group of 4 cells in a line on the board (69 in a
# 6x7 board). Doing this once makes the evaluation function much faster.
# Parameters: none
# Returns: a list of windows, each a tuple of four (row, column) cells
# ---------------------------------------------------------------------
def build_all_windows():
    windows = []
    for row in range(rules.ROWS):
        for column in range(rules.COLS):
            for row_step, column_step in ((0, 1), (1, 0), (1, 1), (1, -1)):
                end_row = row + (rules.WIN_LENGTH - 1) * row_step
                end_column = column + (rules.WIN_LENGTH - 1) * column_step
                if 0 <= end_row < rules.ROWS and 0 <= end_column < rules.COLS:
                    windows.append(tuple(
                        (row + i * row_step, column + i * column_step)
                        for i in range(rules.WIN_LENGTH)))
    return windows


ALL_WINDOWS = build_all_windows()


# ---------------------------------------------------------------------
# score_window
# Scores one 4-cell window from the AI's point of view.
# Parameters:
#   own_count      - how many of the AI's pieces are in the window
#   opponent_count - how many of the opponent's pieces are in the window
# Returns: a positive number if the window helps the AI, negative if it
#          helps the opponent, 0 if it is blocked or empty
# ---------------------------------------------------------------------
def score_window(own_count, opponent_count):
    if own_count and opponent_count:
        return 0                      # both players inside: nobody can use it
    if own_count == 3:
        return THREE_IN_WINDOW
    if own_count == 2:
        return TWO_IN_WINDOW
    if opponent_count == 3:
        return -THREE_IN_WINDOW
    if opponent_count == 2:
        return -TWO_IN_WINDOW
    return 0


# ---------------------------------------------------------------------
# evaluate_board
# Heuristic estimate of how close the AI is to winning a position that
# is not finished yet.
# Parameters:
#   board     - the current 2D board
#   ai_player - which player the AI is (PLAYER_ONE or PLAYER_TWO)
# Returns: a number; higher = better for the AI
# ---------------------------------------------------------------------
def evaluate_board(board, ai_player):
    opponent = rules.get_other_player(ai_player)
    score = 0

    # Pieces in the centre column take part in the most possible lines
    centre = rules.COLS // 2
    for row in range(rules.ROWS):
        if board[row][centre] == ai_player:
            score += CENTRE_PIECE
        elif board[row][centre] == opponent:
            score -= CENTRE_PIECE

    # Look at every possible line of four
    for window in ALL_WINDOWS:
        own_count = 0
        opponent_count = 0
        for row, column in window:
            cell = board[row][column]
            if cell == ai_player:
                own_count += 1
            elif cell == opponent:
                opponent_count += 1
        score += score_window(own_count, opponent_count)
    return score


# ---------------------------------------------------------------------
# SearchResult
# Small record of what the AI decided and why (shown on screen and used
# by the experiments).
#   best_column    - the chosen column (0-6)
#   column_scores  - {column: expected value} for every legal column
#   nodes_searched - how many positions were looked at
#   seconds        - how long the search took
# ---------------------------------------------------------------------
class SearchResult:
    # -----------------------------------------------------------------
    # __init__
    # Stores the search results.
    # Parameters: see the class comment above
    # -----------------------------------------------------------------
    def __init__(self, best_column, column_scores, nodes_searched, seconds):
        self.best_column = best_column
        self.column_scores = column_scores
        self.nodes_searched = nodes_searched
        self.seconds = seconds


# ---------------------------------------------------------------------
# ExpectiminimaxSearch
# Runs one expectiminimax search for one move.
# ---------------------------------------------------------------------
class ExpectiminimaxSearch:
    # -----------------------------------------------------------------
    # __init__
    # Sets up a search.
    # Parameters:
    #   ai_player    - the player the AI is playing as
    #   max_depth    - plies to look ahead (1 ply = one move + its dice roll)
    #   chance_aware - True  = proper expectiminimax (averages over the wind)
    #                  False = plain minimax that wrongly assumes every piece
    #                          lands where it is aimed (used only as a
    #                          comparison in the experiments)
    # -----------------------------------------------------------------
    def __init__(self, ai_player, max_depth, chance_aware=True):
        self.ai_player = ai_player
        self.max_depth = max_depth
        self.chance_aware = chance_aware
        self.nodes_searched = 0
        self.cache = {}          # remembers positions already evaluated

    # -----------------------------------------------------------------
    # get_outcomes
    # The chance outcomes this search believes in for a move.
    # Parameters:
    #   board        - the current 2D board
    #   aimed_column - the column being aimed at
    # Returns: a list of (landing_column, probability) tuples
    # -----------------------------------------------------------------
    def get_outcomes(self, board, aimed_column):
        if self.chance_aware:
            return rules.get_chance_outcomes(board, aimed_column)
        return [(aimed_column, 1.0)]

    # -----------------------------------------------------------------
    # chance_node_value
    # CHANCE node: the expected value of `mover` aiming at `aimed_column`,
    # averaged over every column the wind could blow the piece into.
    # Parameters:
    #   board        - the current 2D board (temporarily changed, then restored)
    #   aimed_column - the column being aimed at
    #   mover        - the player making this move
    #   depth        - plies still left to search, including this one
    # Returns: the probability-weighted average value for the AI
    # -----------------------------------------------------------------
    def chance_node_value(self, board, aimed_column, mover, depth):
        expected_value = 0.0
        for landing_column, probability in self.get_outcomes(board, aimed_column):
            row = rules.drop_piece(board, landing_column, mover)
            self.nodes_searched += 1

            if rules.is_winning_placement(board, row, landing_column, mover):
                # A win sooner (more depth left) is worth more than a win later
                value = WIN_SCORE * depth
                if mover != self.ai_player:
                    value = -value
            elif rules.is_board_full(board):
                value = 0                                   # draw
            elif depth == 1:
                value = evaluate_board(board, self.ai_player)  # depth limit reached
            else:
                value = self.decision_node_value(
                    board, rules.get_other_player(mover), depth - 1)

            rules.remove_piece(board, row, landing_column)   # undo the move
            expected_value += probability * value
        return expected_value

    # -----------------------------------------------------------------
    # decision_node_value
    # MAX node when it is the AI's turn, MIN node when it is the
    # opponent's turn. Tries every legal column.
    # Parameters:
    #   board - the current 2D board
    #   mover - the player whose turn it is
    #   depth - plies still left to search
    # Returns: the best value for the mover (max for AI, min for opponent)
    # -----------------------------------------------------------------
    def decision_node_value(self, board, mover, depth):
        key = (tuple(tuple(row) for row in board), mover, depth)
        if key in self.cache:
            return self.cache[key]

        values = [self.chance_node_value(board, column, mover, depth)
                  for column in CENTRE_FIRST_ORDER if rules.is_valid_column(board, column)]
        result = max(values) if mover == self.ai_player else min(values)

        self.cache[key] = result
        return result

    # -----------------------------------------------------------------
    # find_best_move
    # Root of the search: scores every legal column for the AI and picks
    # the highest.
    # Parameters:
    #   board - the current 2D board (it is not changed)
    # Returns: a SearchResult
    # -----------------------------------------------------------------
    def find_best_move(self, board):
        start_time = time.perf_counter()
        work_board = rules.copy_board(board)
        column_scores = {}
        for column in CENTRE_FIRST_ORDER:
            if rules.is_valid_column(work_board, column):
                column_scores[column] = self.chance_node_value(
                    work_board, column, self.ai_player, self.max_depth)

        # max() keeps the first of equal scores -> centre-most column wins ties
        best_column = max(column_scores, key=column_scores.get)
        seconds = time.perf_counter() - start_time
        return SearchResult(best_column, column_scores, self.nodes_searched, seconds)


# =====================================================================
#  Agents - a common interface so different AIs can play each other in
#  the experiments (experiments.py) and in the game.
# =====================================================================

# ---------------------------------------------------------------------
# ExpectiminimaxAgent
# Plays using expectiminimax to a fixed depth.
# ---------------------------------------------------------------------
class ExpectiminimaxAgent:
    # -----------------------------------------------------------------
    # __init__
    # Parameters:
    #   depth        - how many plies to look ahead
    #   name         - label used in results tables (optional)
    #   chance_aware - False turns it into plain minimax that ignores the
    #                  wind (comparison baseline for the experiments)
    # -----------------------------------------------------------------
    def __init__(self, depth, name=None, chance_aware=True):
        self.depth = depth
        self.chance_aware = chance_aware
        self.name = name or "Expectiminimax (depth %d)" % depth
        self.last_result = None

    # -----------------------------------------------------------------
    # choose_column
    # Picks a column for the given position.
    # Parameters:
    #   board  - the current 2D board
    #   player - the player this agent is playing as
    #   rng    - random generator (unused, kept for a common interface)
    # Returns: the chosen column index
    # -----------------------------------------------------------------
    def choose_column(self, board, player, rng=random):
        search = ExpectiminimaxSearch(player, self.depth, self.chance_aware)
        self.last_result = search.find_best_move(board)
        return self.last_result.best_column


# ---------------------------------------------------------------------
# RandomAgent
# Baseline opponent: picks any legal column at random.
# ---------------------------------------------------------------------
class RandomAgent:
    # -----------------------------------------------------------------
    # __init__
    # Parameters: none
    # -----------------------------------------------------------------
    def __init__(self):
        self.name = "Random"
        self.last_result = None

    # -----------------------------------------------------------------
    # choose_column
    # Parameters:
    #   board  - the current 2D board
    #   player - the player this agent is playing as (unused)
    #   rng    - random generator used to pick the column
    # Returns: a random legal column index
    # -----------------------------------------------------------------
    def choose_column(self, board, player, rng=random):
        return rng.choice(rules.get_valid_columns(board))
