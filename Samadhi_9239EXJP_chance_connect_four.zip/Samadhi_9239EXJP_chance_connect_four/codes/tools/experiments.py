# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  experiments.py
#  Experimentally evaluates and compares the AI methods by making them
#  play many games against each other (the "Testing and results" part).
#
#  Agents compared
#    Random                - picks any legal column
#    Greedy (depth 1)      - expectiminimax looking at its own move only
#    Expectiminimax d2     - looks 2 plies ahead (the "Medium" AI)
#    Expectiminimax d4     - looks 4 plies ahead (the "Hard" AI)
#    Minimax d4 (no dice)  - same depth as Hard, but IGNORES the wind -
#                            shows why modelling chance matters
#
#  Each match-up is played GAMES_PER_MATCHUP times. The first player
#  alternates every game so neither side gets the first-move advantage.
#  Results are saved to results/ as CSV, Markdown and a PNG chart.
#
#  Run from the project folder:   python tools/experiments.py
# =====================================================================

import csv
import os
import random
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game"))

import ai              # noqa: E402
import board as rules  # noqa: E402

RESULTS_DIR = os.path.join(HERE, "..", "results")
GAMES_PER_MATCHUP = 300
BASE_SEED = 2026


# ---------------------------------------------------------------------
# make_agent
# Creates an agent from a short code (so it can be sent to worker
# processes easily).
# Parameters:
#   code - one of "random", "greedy", "emm2", "emm4", "minimax4"
# Returns: an agent object with choose_column() and a name
# ---------------------------------------------------------------------
def make_agent(code):
    if code == "random":
        return ai.RandomAgent()
    if code == "greedy":
        return ai.ExpectiminimaxAgent(1, "Greedy (depth 1)")
    if code == "emm2":
        return ai.ExpectiminimaxAgent(2, "Expectiminimax d2")
    if code == "emm4":
        return ai.ExpectiminimaxAgent(4, "Expectiminimax d4")
    if code == "minimax4":
        return ai.ExpectiminimaxAgent(4, "Minimax d4 (ignores dice)", chance_aware=False)
    raise ValueError(code)


MATCHUPS = [
    ("greedy", "random"),
    ("emm2", "random"),
    ("emm2", "greedy"),
    ("emm4", "greedy"),
    ("emm4", "emm2"),
    ("emm4", "minimax4"),
]


# ---------------------------------------------------------------------
# play_game
# Plays one complete game between two agents.
# Parameters:
#   job - tuple (code_a, code_b, game_index):
#           code_a, code_b - agent codes (see make_agent)
#           game_index     - number of the game; decides who starts and
#                            seeds the dice so results are repeatable
# Returns: dict with the winner ("A", "B" or "draw"), number of moves,
#          and total thinking time / move count for each agent
# ---------------------------------------------------------------------
def play_game(job):
    code_a, code_b, game_index = job
    rng = random.Random(BASE_SEED + game_index * 7919)
    agent_a, agent_b = make_agent(code_a), make_agent(code_b)

    # Agent A is player one in even games and player two in odd games
    if game_index % 2 == 0:
        seats = {rules.PLAYER_ONE: ("A", agent_a), rules.PLAYER_TWO: ("B", agent_b)}
    else:
        seats = {rules.PLAYER_ONE: ("B", agent_b), rules.PLAYER_TWO: ("A", agent_a)}

    board = rules.create_board()
    player = rules.PLAYER_ONE
    think_time = {"A": 0.0, "B": 0.0}
    move_count = {"A": 0, "B": 0}
    moves = 0
    while True:
        label, agent = seats[player]
        start = time.perf_counter()
        aimed = agent.choose_column(board, player, rng)
        think_time[label] += time.perf_counter() - start
        move_count[label] += 1

        drift = rules.DIE_FACE_TO_DRIFT[rules.roll_wind_die(rng)]
        landing = rules.resolve_landing_column(board, aimed, drift)
        row = rules.drop_piece(board, landing, player)
        moves += 1

        if rules.is_winning_placement(board, row, landing, player):
            winner = label
            break
        if rules.is_board_full(board):
            winner = "draw"
            break
        player = rules.get_other_player(player)

    return {"winner": winner, "moves": moves,
            "time_a": think_time["A"], "moves_a": move_count["A"],
            "time_b": think_time["B"], "moves_b": move_count["B"]}


# ---------------------------------------------------------------------
# run_matchup
# Plays all the games for one pairing (in parallel) and sums them up.
# Parameters:
#   pool   - multiprocessing Pool used to play games in parallel
#   code_a - agent code of the first agent
#   code_b - agent code of the second agent
# Returns: dict of totals for the results table
# ---------------------------------------------------------------------
def run_matchup(pool, code_a, code_b):
    jobs = [(code_a, code_b, index) for index in range(GAMES_PER_MATCHUP)]
    games = pool.map(play_game, jobs)
    wins_a = sum(game["winner"] == "A" for game in games)
    wins_b = sum(game["winner"] == "B" for game in games)
    draws = GAMES_PER_MATCHUP - wins_a - wins_b
    return {
        "agent_a": make_agent(code_a).name,
        "agent_b": make_agent(code_b).name,
        "games": GAMES_PER_MATCHUP,
        "wins_a": wins_a,
        "wins_b": wins_b,
        "draws": draws,
        "win_rate_a": round(100.0 * wins_a / GAMES_PER_MATCHUP, 1),
        "avg_game_length": round(sum(g["moves"] for g in games) / len(games), 1),
        "ms_per_move_a": round(1000 * sum(g["time_a"] for g in games)
                               / max(1, sum(g["moves_a"] for g in games)), 1),
        "ms_per_move_b": round(1000 * sum(g["time_b"] for g in games)
                               / max(1, sum(g["moves_b"] for g in games)), 1),
    }


# ---------------------------------------------------------------------
# measure_search_effort
# Records how many positions each depth searches from the empty board
# and from a typical mid-game position.
# Parameters: none
# Returns: list of dicts (depth, nodes, milliseconds)
# ---------------------------------------------------------------------
def measure_search_effort():
    rng = random.Random(BASE_SEED)
    mid_game = rules.create_board()
    for turn in range(10):
        rules.drop_piece(mid_game, rng.choice(rules.get_valid_columns(mid_game)),
                         rules.PLAYER_ONE if turn % 2 == 0 else rules.PLAYER_TWO)
    rows = []
    for depth in (1, 2, 3, 4, 5):
        for label, position in (("empty board", rules.create_board()), ("mid-game", mid_game)):
            result = ai.ExpectiminimaxSearch(rules.PLAYER_ONE, depth).find_best_move(position)
            rows.append({"depth": depth, "position": label,
                         "nodes": result.nodes_searched,
                         "ms": round(result.seconds * 1000, 1)})
    return rows


# ---------------------------------------------------------------------
# agreement_in_game
# Plays one Medium-vs-Medium game and, at every position, asks both the
# chance-aware Expectiminimax (depth 4) and the dice-ignoring Minimax
# (depth 4) which column they would choose.
# Parameters:
#   game_index - seeds the dice so the result is repeatable
# Returns: (positions compared, positions where both chose the same column)
# ---------------------------------------------------------------------
def agreement_in_game(game_index):
    rng = random.Random(BASE_SEED + 104729 * (game_index + 1))
    driver = make_agent("emm2")
    expecti, minimax = make_agent("emm4"), make_agent("minimax4")
    board = rules.create_board()
    player = rules.PLAYER_ONE
    compared = same = 0
    while True:
        compared += 1
        if expecti.choose_column(board, player) == minimax.choose_column(board, player):
            same += 1
        # Random opening moves give a wider variety of positions
        if compared <= 4:
            aimed = rng.choice(rules.get_valid_columns(board))
        else:
            aimed = driver.choose_column(board, player)
        drift = rules.DIE_FACE_TO_DRIFT[rules.roll_wind_die(rng)]
        landing = rules.resolve_landing_column(board, aimed, drift)
        row = rules.drop_piece(board, landing, player)
        if rules.is_winning_placement(board, row, landing, player) or rules.is_board_full(board):
            return compared, same
        player = rules.get_other_player(player)


# ---------------------------------------------------------------------
# measure_agreement
# How often does modelling the dice change the chosen move?
# Parameters:
#   pool  - multiprocessing Pool
#   games - number of games to sample positions from
# Returns: dict with positions compared, same choices and the percentage
# ---------------------------------------------------------------------
def measure_agreement(pool, games=60):
    totals = pool.map(agreement_in_game, range(games))
    compared = sum(t[0] for t in totals)
    same = sum(t[1] for t in totals)
    return {"positions": compared, "same_choice": same,
            "agreement_percent": round(100.0 * same / compared, 1)}


# ---------------------------------------------------------------------
# save_chart
# Draws a bar chart of win rates (needs matplotlib; skipped if missing).
# Parameters:
#   results - list of result dicts from run_matchup
#   path    - where to save the PNG
# ---------------------------------------------------------------------
def save_chart(results, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed - chart skipped")
        return
    labels = ["%s\nvs %s" % (r["agent_a"], r["agent_b"]) for r in results]
    wins_a = [100.0 * r["wins_a"] / r["games"] for r in results]
    draws = [100.0 * r["draws"] / r["games"] for r in results]
    wins_b = [100.0 * r["wins_b"] / r["games"] for r in results]

    figure, axis = plt.subplots(figsize=(11, 5.2), dpi=160)
    positions = range(len(results))
    axis.barh(positions, wins_a, color="#16a34a", label="First-named agent wins")
    axis.barh(positions, draws, left=wins_a, color="#94a3b8", label="Draw")
    axis.barh(positions, wins_b, left=[a + d for a, d in zip(wins_a, draws)],
              color="#dc2626", label="Second-named agent wins")
    for index, value in enumerate(wins_a):
        axis.text(value / 2, index, "%.0f%%" % value, va="center", ha="center",
                  color="white", fontsize=10, fontweight="bold")
    axis.set_yticks(list(positions))
    axis.set_yticklabels(labels, fontsize=9)
    axis.invert_yaxis()
    axis.set_xlim(0, 100)
    axis.set_xlabel("%% of %d games" % GAMES_PER_MATCHUP)
    axis.set_title("Chance Connect Four - AI head-to-head results")
    axis.legend(loc="lower center", bbox_to_anchor=(0.5, -0.32), ncol=3, frameon=False)
    for side in ("top", "right"):
        axis.spines[side].set_visible(False)
    figure.tight_layout()
    figure.savefig(path)
    print("saved", path)


# ---------------------------------------------------------------------
# main
# Runs every experiment and writes the result files.
# Parameters: none
# ---------------------------------------------------------------------
def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    results = []
    with Pool() as pool:
        for code_a, code_b in MATCHUPS:
            start = time.time()
            result = run_matchup(pool, code_a, code_b)
            results.append(result)
            print("%-28s vs %-28s  A wins %3d  B wins %3d  draws %3d   (%.0fs)" % (
                result["agent_a"], result["agent_b"], result["wins_a"], result["wins_b"],
                result["draws"], time.time() - start))
        agreement = measure_agreement(pool)
        print("Expectiminimax d4 and Minimax d4 chose the same column in %.1f%% of %d positions"
              % (agreement["agreement_percent"], agreement["positions"]))

    effort = measure_search_effort()

    with open(os.path.join(RESULTS_DIR, "head_to_head.csv"), "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)
    with open(os.path.join(RESULTS_DIR, "search_effort.csv"), "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(effort[0].keys()))
        writer.writeheader()
        writer.writerows(effort)

    with open(os.path.join(RESULTS_DIR, "results.md"), "w") as handle:
        handle.write("# Experiment results (%d games per match-up, first player alternates)\n\n"
                     % GAMES_PER_MATCHUP)
        handle.write("| Agent A | Agent B | A wins | B wins | Draws | A win % | Avg moves/game"
                     " | A ms/move | B ms/move |\n|---|---|---|---|---|---|---|---|---|\n")
        for r in results:
            handle.write("| %s | %s | %d | %d | %d | %.1f%% | %.1f | %.1f | %.1f |\n" % (
                r["agent_a"], r["agent_b"], r["wins_a"], r["wins_b"], r["draws"],
                r["win_rate_a"], r["avg_game_length"], r["ms_per_move_a"], r["ms_per_move_b"]))
        handle.write("\n# Search effort per move\n\n| Depth | Position | Positions searched"
                     " | Time (ms) |\n|---|---|---|---|\n")
        for e in effort:
            handle.write("| %d | %s | %s | %.1f |\n" % (e["depth"], e["position"],
                                                       "{:,}".format(e["nodes"]), e["ms"]))
        handle.write("\n# Does modelling the dice change the move?\n\n"
                     "Expectiminimax d4 and Minimax d4 (ignores dice) chose the same column in "
                     "%d of %d positions (%.1f%%).\n" % (agreement["same_choice"],
                                                       agreement["positions"],
                                                       agreement["agreement_percent"]))
    with open(os.path.join(RESULTS_DIR, "agreement.csv"), "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(agreement.keys()))
        writer.writeheader()
        writer.writerow(agreement)

    save_chart(results, os.path.join(RESULTS_DIR, "head_to_head.png"))
    print(open(os.path.join(RESULTS_DIR, "results.md")).read())


if __name__ == "__main__":
    main()
