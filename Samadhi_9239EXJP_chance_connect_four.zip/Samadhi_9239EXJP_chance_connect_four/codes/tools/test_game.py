# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  test_game.py
#  Unit tests for the rules (board.py) and the AI (ai.py).
#  Run from the project folder:   python tools/test_game.py
# =====================================================================

import os
import random
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "game"))

import ai              # noqa: E402
import board as rules  # noqa: E402

X, O = rules.PLAYER_ONE, rules.PLAYER_TWO


# ---------------------------------------------------------------------
# board_from_rows
# Builds a board from 6 strings such as ". . X O . . ." (top row first).
# Parameters:
#   rows - list of 6 strings, '.' empty, 'X' player one, 'O' player two
# Returns: a 2D board list
# ---------------------------------------------------------------------
def board_from_rows(rows):
    lookup = {".": rules.EMPTY, "X": X, "O": O}
    return [[lookup[symbol] for symbol in row.split()] for row in rows]


class RulesTests(unittest.TestCase):
    # Pieces stack from the bottom up
    def test_drop_stacks_from_bottom(self):
        board = rules.create_board()
        self.assertEqual(rules.drop_piece(board, 3, X), 5)
        self.assertEqual(rules.drop_piece(board, 3, O), 4)

    # A full column is no longer a valid move
    def test_full_column_is_invalid(self):
        board = rules.create_board()
        for _ in range(rules.ROWS):
            rules.drop_piece(board, 0, X)
        self.assertFalse(rules.is_valid_column(board, 0))
        self.assertNotIn(0, rules.get_valid_columns(board))

    # Chance outcome probabilities always add up to exactly 1
    def test_chance_probabilities_sum_to_one(self):
        rng = random.Random(7)
        board = rules.create_board()
        for _ in range(25):
            for column in rules.get_valid_columns(board):
                total = sum(p for _, p in rules.get_chance_outcomes(board, column))
                self.assertAlmostEqual(total, 1.0)
            rules.drop_piece(board, rng.choice(rules.get_valid_columns(board)), X)

    # At the left edge a "left gust" is blocked, so the piece stays put (5/6)
    def test_edge_column_merges_blocked_gust(self):
        outcomes = dict(rules.get_chance_outcomes(rules.create_board(), 0))
        self.assertAlmostEqual(outcomes[0], 5 / 6)
        self.assertAlmostEqual(outcomes[1], 1 / 6)

    # A gust into a full column is blocked too
    def test_gust_into_full_column_is_blocked(self):
        board = rules.create_board()
        for _ in range(rules.ROWS):
            rules.drop_piece(board, 4, X)
        self.assertEqual(rules.resolve_landing_column(board, 3, +1), 3)
        self.assertEqual(rules.resolve_landing_column(board, 3, -1), 2)

    # Horizontal, vertical and both diagonal wins are detected
    def test_win_detection_all_directions(self):
        lines = {
            "horizontal": [(5, 0), (5, 1), (5, 2), (5, 3)],
            "vertical": [(5, 6), (4, 6), (3, 6), (2, 6)],
            "diagonal_up": [(5, 0), (4, 1), (3, 2), (2, 3)],
            "diagonal_down": [(2, 0), (3, 1), (4, 2), (5, 3)],
        }
        for name, cells in lines.items():
            board = rules.create_board()
            for row, column in cells:
                board[row][column] = X
            last_row, last_column = cells[-1]
            self.assertTrue(rules.is_winning_placement(board, last_row, last_column, X), name)
            self.assertEqual(sorted(rules.get_winning_cells(board, X)), sorted(cells), name)

    # Three in a row is not a win
    def test_three_is_not_a_win(self):
        board = rules.create_board()
        for column in range(3):
            board[5][column] = X
        self.assertFalse(rules.is_winning_placement(board, 5, 2, X))


class AITests(unittest.TestCase):
    # The AI takes an immediate win when one is available
    def test_ai_takes_winning_move(self):
        board = board_from_rows([
            ". . . . . . .",
            ". . . . . . .",
            ". . . . . . .",
            ". . . O . . .",
            ". . . O X . .",
            ". X X O X . .",
        ])
        result = ai.ExpectiminimaxSearch(O, 2).find_best_move(board)
        self.assertEqual(result.best_column, 3)

    # The AI blocks the opponent's immediate threat
    def test_ai_blocks_vertical_threat(self):
        board = board_from_rows([
            ". . . . . . .",
            ". . . . . . .",
            ". . . . . . .",
            ". X . . . . .",
            ". X . . . O .",
            ". X . . O O .",
        ])
        result = ai.ExpectiminimaxSearch(O, 2).find_best_move(board)
        self.assertEqual(result.best_column, 1)

    # The search must leave the real board unchanged
    def test_search_does_not_change_board(self):
        board = rules.create_board()
        rules.drop_piece(board, 3, X)
        before = rules.copy_board(board)
        ai.ExpectiminimaxSearch(O, 3).find_best_move(board)
        self.assertEqual(board, before)

    # The evaluation is symmetric: swapping sides flips the sign
    def test_evaluation_is_symmetric(self):
        board = board_from_rows([
            ". . . . . . .",
            ". . . . . . .",
            ". . . . . . .",
            ". . . X . . .",
            ". . O X . . .",
            ". O O X X . .",
        ])
        self.assertEqual(ai.evaluate_board(board, X), -ai.evaluate_board(board, O))

    # On an empty board the AI prefers the centre column
    def test_prefers_centre_on_empty_board(self):
        result = ai.ExpectiminimaxSearch(X, 2).find_best_move(rules.create_board())
        self.assertEqual(result.best_column, 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
