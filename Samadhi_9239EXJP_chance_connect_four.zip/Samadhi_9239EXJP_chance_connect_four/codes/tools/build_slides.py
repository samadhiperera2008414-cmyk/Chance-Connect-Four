# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  build_slides.py
#  Generates the 10-slide presentation deck (PPTX) from the project's
#  config, screenshots and experiment results. Re-run after changing
#  the student name / links in game/config.py or re-running experiments.
#  Run from the project folder:   python tools/build_slides.py
# =====================================================================

import csv
import os
import sys

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "game"))
import config  # noqa: E402

SHOTS = os.path.join(ROOT, "backup", "screenshots")
FILE_TITLE = "%s_ChanceConnectFour" % config.STUDENT_NAME.replace(" ", "")
OUTPUT = os.path.join(ROOT, "slides", FILE_TITLE + ".pptx")

# ---- Palette (taken from the game itself) ----
NAVY = "0F172A"
SLATE = "1E293B"
INK = "0F172A"
MUTED = "64748B"
CARD = "F1F5F9"
BLUE = "2563EB"
RED = "EF4444"
YELLOW = "FACC15"
GREEN = "16A34A"
WHITE = "FFFFFF"
SKY = "38BDF8"

HEAD_FONT = "Arial"
BODY_FONT = "Calibri"
CODE_FONT = "Courier New"


# ---------------------------------------------------------------------
# rgb - converts "RRGGBB" to an RGBColor.
# Parameters: hex_colour - six-digit hex string
# ---------------------------------------------------------------------
def rgb(hex_colour):
    return RGBColor.from_string(hex_colour)


# ---------------------------------------------------------------------
# add_text - adds a text box.
# Parameters:
#   slide       - slide to add to
#   x, y, w, h  - position and size in inches
#   paragraphs  - a string, or a list of strings / lists of (text, options) runs
#   size, colour, bold, font, align - default text style
#   anchor      - vertical alignment inside the box
#   bullets     - True to give each paragraph a bullet
#   spacing     - points of space after each paragraph
# Returns: the text box shape
# ---------------------------------------------------------------------
def add_text(slide, x, y, w, h, paragraphs, size=16, colour=INK, bold=False, font=BODY_FONT,
             align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, bullets=False, spacing=6):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = box.text_frame
    frame.word_wrap = True
    frame.vertical_anchor = anchor
    for side in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
        setattr(frame, side, 0)
    if isinstance(paragraphs, str):
        paragraphs = [paragraphs]
    for index, paragraph_content in enumerate(paragraphs):
        paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
        paragraph.alignment = align
        paragraph.space_after = Pt(spacing)
        runs = paragraph_content if isinstance(paragraph_content, list) else [(paragraph_content, {})]
        for text, options in runs:
            run = paragraph.add_run()
            run.text = text
            run.font.size = Pt(options.get("size", size))
            run.font.bold = options.get("bold", bold)
            run.font.italic = options.get("italic", False)
            run.font.name = options.get("font", font)
            run.font.color.rgb = rgb(options.get("colour", colour))
        if bullets:
            set_bullet(paragraph, size)
    return box


# ---------------------------------------------------------------------
# set_bullet - turns a paragraph into a real bulleted list item.
# Parameters: paragraph - pptx paragraph;  size - font size (sets indent)
# ---------------------------------------------------------------------
def set_bullet(paragraph, size):
    properties = paragraph._p.get_or_add_pPr()
    properties.set("marL", str(int(Pt(size * 1.2))))
    properties.set("indent", str(-int(Pt(size * 1.2))))
    bullet = properties.makeelement(qn("a:buChar"), {"char": "•"})
    properties.append(bullet)


# ---------------------------------------------------------------------
# add_box - adds a rounded rectangle (card) with optional text.
# Parameters:
#   slide, x, y, w, h - slide and geometry (inches)
#   fill              - fill colour hex
#   radius            - corner rounding (0-0.5)
#   line              - outline colour hex or None
# Returns: the shape
# ---------------------------------------------------------------------
def add_box(slide, x, y, w, h, fill=CARD, radius=0.08, line=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y),
                                   Inches(w), Inches(h))
    shape.adjustments[0] = radius
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(fill)
    if line:
        shape.line.color.rgb = rgb(line)
        shape.line.width = Pt(1.5)
    else:
        shape.line.fill.background()
    shape.shadow.inherit = False
    return shape


# ---------------------------------------------------------------------
# add_piece - a round "game piece" with a label (the deck's visual motif).
# Parameters:
#   slide, x, y   - top-left in inches
#   diameter      - size in inches
#   fill          - piece colour
#   label         - text inside
#   text_colour   - label colour
#   size          - label font size
# ---------------------------------------------------------------------
def add_piece(slide, x, y, diameter, fill, label="", text_colour=WHITE, size=16):
    shape = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y),
                                   Inches(diameter), Inches(diameter))
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(fill)
    shape.line.fill.background()
    shape.shadow.inherit = False
    if label:
        frame = shape.text_frame
        for side in ("margin_left", "margin_right", "margin_top", "margin_bottom"):
            setattr(frame, side, 0)
        frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        paragraph = frame.paragraphs[0]
        paragraph.alignment = PP_ALIGN.CENTER
        run = paragraph.add_run()
        run.text = label
        run.font.size = Pt(size)
        run.font.bold = True
        run.font.name = HEAD_FONT
        run.font.color.rgb = rgb(text_colour)
    return shape


# ---------------------------------------------------------------------
# new_slide - blank slide with background, title and footer.
# Parameters:
#   deck   - the Presentation
#   title  - slide title (None for none)
#   dark   - True for the navy background
#   number - slide number shown in the footer
#   notes  - speaker notes text
# Returns: the slide
# ---------------------------------------------------------------------
def new_slide(deck, title, dark=False, number=None, notes=""):
    slide = deck.slides.add_slide(deck.slide_layouts[6])
    background = slide.background.fill
    background.solid()
    background.fore_color.rgb = rgb(NAVY if dark else WHITE)
    if title:
        add_text(slide, 0.6, 0.45, 12.1, 0.8, title, size=34, bold=True, font=HEAD_FONT,
                 colour=WHITE if dark else INK, anchor=MSO_ANCHOR.MIDDLE)
    if number:
        footer = "%s  |  %s  |  5FTC2067 AI Principles" % (config.STUDENT_NAME, config.STUDENT_ID)
        add_text(slide, 0.6, 7.0, 8, 0.3, footer, size=10, colour="94A3B8" if dark else MUTED)
        add_text(slide, 11.7, 7.0, 1.0, 0.3, str(number), size=10, align=PP_ALIGN.RIGHT,
                 colour="94A3B8" if dark else MUTED)
    if notes:
        slide.notes_slide.notes_text_frame.text = notes
    return slide


# ---------------------------------------------------------------------
# add_picture - adds a screenshot with a thin border.
# Parameters: slide, path, x, y, w - picture and geometry (height keeps 4:3)
# ---------------------------------------------------------------------
def add_picture(slide, path, x, y, w):
    picture = slide.shapes.add_picture(path, Inches(x), Inches(y), width=Inches(w))
    picture.line.color.rgb = rgb("CBD5E1")
    picture.line.width = Pt(1)
    return picture


# ---------------------------------------------------------------------
# load_results - reads the experiment CSV (if the experiments were run).
# Parameters: none
# Returns: list of row dicts, or [] if missing
# ---------------------------------------------------------------------
def load_results():
    return load_csv("head_to_head.csv")


# ---------------------------------------------------------------------
# load_csv - reads any CSV file from the results folder.
# Parameters: name - file name inside results/
# Returns: list of row dicts, or [] if the file is missing
# ---------------------------------------------------------------------
def load_csv(name):
    path = os.path.join(ROOT, "results", name)
    if not os.path.exists(path):
        return []
    with open(path) as handle:
        return list(csv.DictReader(handle))


SHORT_LABELS = ["Greedy vs Random", "EMM-2 vs Random", "EMM-2 vs Greedy",
                "EMM-4 vs Greedy", "EMM-4 vs EMM-2", "EMM-4 vs Minimax-4 (ignores dice)"]


# ---------------------------------------------------------------------
# build - creates all ten slides and saves the deck.
# Parameters: none
# ---------------------------------------------------------------------
def build():
    deck = Presentation()
    deck.slide_width = Inches(13.333)
    deck.slide_height = Inches(7.5)
    deck.core_properties.author = config.STUDENT_NAME
    deck.core_properties.title = "Chance Connect Four"
    results = load_results()
    effort = load_csv("search_effort.csv")
    agreement = (load_csv("agreement.csv") or [{"agreement_percent": "0"}])[0]
    games_each = int(results[0]["games"]) if results else 0
    total_games = games_each * len(results)

    # ================= 1. Title =================
    s = new_slide(deck, None, dark=True, notes=(
        "Hello, I'm %s. My project is Chance Connect Four: a two-player Connect Four game with a "
        "dice-driven wind twist, and an AI opponent that uses Expectiminimax to plan around the "
        "luck. I'll cover the concept, the design, how the AI works, how I tested it, and then "
        "show the published game live." % config.STUDENT_NAME))
    add_text(s, 0.7, 1.0, 6.2, 0.4, "5FTC2067 ARTIFICIAL INTELLIGENCE PRINCIPLES  |  MINI PROJECT",
             size=12, bold=True, colour=SKY)
    add_text(s, 0.7, 1.55, 6.2, 1.9, ["Chance", "Connect Four"], size=54, bold=True,
             font=HEAD_FONT, colour=WHITE, spacing=0)
    add_text(s, 0.7, 3.55, 5.9, 0.9,
             "Connect Four where the wind has a say, and an Expectiminimax AI that plans for it",
             size=18, colour="CBD5E1")
    for index in range(7):
        add_piece(s, 0.7 + index * 0.5, 4.65, 0.36, RED if index % 2 == 0 else YELLOW)
    add_text(s, 0.7, 5.4, 6, 1.0,
             [[("Student: ", {"colour": "94A3B8"}), (config.STUDENT_NAME, {"bold": True})],
              [("Student ID: ", {"colour": "94A3B8"}), (config.STUDENT_ID, {"bold": True})]],
             size=16, colour=WHITE)
    add_picture(s, os.path.join(SHOTS, "01_menu.png"), 7.1, 1.35, 5.6)

    # ================= 2. Overview & concept =================
    s = new_slide(deck, "Project overview: Connect Four + a wind die", number=2, notes=(
        "The brief asks for a two-player game that involves chance. I took Connect Four, which "
        "everyone knows, and added a wind die. You choose a column, then roll: a 1 blows your "
        "piece one column left, a 6 blows it right, and 2 to 5 means calm air. So two thirds of "
        "the time you get what you aimed for, and one third of the time the wind decides. That "
        "makes every move a gamble, and the AI has to reason about probabilities, not just moves."))
    add_text(s, 0.6, 1.6, 5.6, 4.8, [
        [("The game", {"bold": True, "size": 20})],
        "Classic 6 x 7 Connect Four for two players: line up four pieces to win.",
        [("The twist", {"bold": True, "size": 20})],
        "After choosing a column, the player rolls a six-sided wind die that can blow the "
        "piece one column sideways.",
        [("Why it fits the brief", {"bold": True, "size": 20})],
        "A two-player game with real chance. The AI cannot know where a piece will land, so it "
        "must weigh every possible outcome by its probability.",
    ], size=16, spacing=8)
    faces = [("1", "Gust LEFT", "1 in 6  =  17%", BLUE), ("2-5", "Calm: lands where aimed",
                                                          "4 in 6  =  67%", GREEN),
             ("6", "Gust RIGHT", "1 in 6  =  17%", BLUE)]
    for index, (face, label, odds, colour) in enumerate(faces):
        y = 1.65 + index * 1.45
        add_box(s, 6.8, y, 5.9, 1.2)
        add_piece(s, 7.05, y + 0.2, 0.8, colour, face, size=20 if len(face) == 1 else 15)
        add_text(s, 8.1, y + 0.22, 4.4, 0.4, label, size=18, bold=True)
        add_text(s, 8.1, y + 0.66, 4.4, 0.35, odds, size=14, colour=MUTED)
    add_text(s, 6.8, 6.05, 5.9, 0.6,
             "Blocked gust (board edge or full column): the piece lands where it was aimed.",
             size=13, colour=MUTED)

    # ================= 3. Objectives & target players =================
    s = new_slide(deck, "Objectives and target players", number=3, notes=(
        "My objectives were: build a complete, polished chance game; implement Expectiminimax "
        "as the brief describes, evaluating all consequences of each move; publish it so anyone "
        "can play in a browser; and test the AI experimentally against other methods. The game "
        "is aimed at casual players who want a quick five-minute match, and at students who want "
        "to see how a game AI thinks, because the game shows the AI's reasoning on screen."))
    add_box(s, 0.6, 1.6, 6.9, 5.1)
    add_text(s, 0.95, 1.85, 6.2, 0.5, "Objectives", size=22, bold=True, font=HEAD_FONT)
    objectives = [
        ("Build", "a complete, attractive two-player game with chance"),
        ("Implement", "Expectiminimax: evaluate every move, every die roll and every reply"),
        ("Publish", "a browser version anyone can play from a link"),
        ("Evaluate", "the AI against Random, Greedy and no-dice Minimax in %s test games"
         % "{:,}".format(total_games)),
    ]
    for index, (verb, rest) in enumerate(objectives):
        y = 2.6 + index * 0.98
        add_piece(s, 0.95, y, 0.55, RED if index % 2 == 0 else YELLOW, str(index + 1),
                  text_colour=WHITE if index % 2 == 0 else INK)
        add_text(s, 1.75, y + 0.02, 5.5, 0.9, [[(verb + " ", {"bold": True}), (rest, {})]], size=16)
    add_box(s, 7.8, 1.6, 4.9, 5.1, fill=NAVY)
    add_text(s, 8.15, 1.85, 4.3, 0.5, "Target players", size=22, bold=True, font=HEAD_FONT,
             colour=WHITE)
    players = [("Casual players", "Quick 3-5 minute matches; rules learned in seconds"),
               ("Friends", "Two-player mode on one screen"),
               ("AI learners", "Live chart shows how the AI scores every column")]
    for index, (who, why) in enumerate(players):
        y = 2.6 + index * 1.3
        add_text(s, 8.15, y, 4.3, 0.4, who, size=17, bold=True, colour=YELLOW)
        add_text(s, 8.15, y + 0.42, 4.3, 0.8, why, size=15, colour="E2E8F0")

    # ================= 4. Game design =================
    s = new_slide(deck, "Game design: mechanics, rules and features", number=4, notes=(
        "Here is the game screen. When you hover over a column, it shows the exact chance of the "
        "piece landing in each column. The right panel shows the score, the wind die, and the "
        "AI analysis chart. There are three difficulty levels, which are simply how many moves "
        "ahead the AI searches, plus two-player and AI-versus-AI modes."))
    add_picture(s, os.path.join(SHOTS, "02_human_turn_with_odds.png"), 0.6, 1.6, 5.9)
    features = [
        ("Wind die", "1 left, 2-5 calm, 6 right; animated roll and gust"),
        ("Live odds", "Hover a column to see landing chances (17/67/17%)"),
        ("Win rule", "4 in a row in any direction; full board = draw"),
        ("3 AI levels", "Easy, Medium, Hard = look-ahead of 1, 2, 4 moves"),
        ("3 modes", "vs AI, two players, watch AI vs AI"),
        ("AI analysis", "Bar chart of the AI's value for every column"),
    ]
    for index, (name, detail) in enumerate(features):
        column, row = index % 2, index // 2
        x, y = 6.9 + column * 2.95, 1.6 + row * 1.5
        add_box(s, x, y, 2.8, 1.35)
        add_piece(s, x + 0.2, y + 0.2, 0.3, RED if index % 2 == 0 else YELLOW)
        add_text(s, x + 0.62, y + 0.17, 2.1, 0.4, name, size=15, bold=True)
        add_text(s, x + 0.2, y + 0.62, 2.45, 0.7, detail, size=12, colour=MUTED)
    add_text(s, 6.9, 6.2, 5.8, 0.5, "Keys: 1-7 drop a piece  |  R restart  |  M menu",
             size=12, colour=MUTED)

    # ================= 5. Tools =================
    s = new_slide(deck, "Tools, technologies and assets", number=5, notes=(
        "Everything is written in Python. Pygame handles graphics and input. pygbag compiles the "
        "same Python code to WebAssembly so it runs in a browser, and itch.io hosts it. I used "
        "unittest for the rules and AI tests, and matplotlib for the results chart. All the "
        "graphics, including the board, pieces, die and animations, are drawn in code, so there "
        "are no third-party assets and all the code is my own."))
    tools = [("Py", "Python 3", "All game, AI and test code", BLUE),
             ("PG", "Pygame 2.6", "Graphics, input, animation", GREEN),
             ("WA", "pygbag", "Python to WebAssembly for the browser", "7C3AED"),
             ("IO", "itch.io", "Free hosting and public play link", RED),
             ("UT", "unittest", "12 automated rules and AI tests", "0891B2"),
             ("MP", "matplotlib", "Experiment results chart", "EA580C")]
    for index, (initials, name, use, colour) in enumerate(tools):
        column, row = index % 3, index // 3
        x, y = 0.6 + column * 4.1, 1.65 + row * 1.85
        add_box(s, x, y, 3.85, 1.6)
        add_piece(s, x + 0.25, y + 0.38, 0.85, colour, initials, size=18)
        add_text(s, x + 1.3, y + 0.38, 2.4, 0.4, name, size=18, bold=True)
        add_text(s, x + 1.3, y + 0.8, 2.4, 0.7, use, size=13, colour=MUTED)
    add_box(s, 0.6, 5.5, 12.1, 1.2, fill=NAVY)
    add_text(s, 0.95, 5.62, 11.4, 1.0, [
        [("Assets: ", {"bold": True, "colour": YELLOW}),
         ("every visual (board, pieces, die, wind streaks, charts) is drawn in code with Pygame. "
          "No third-party images or sounds, and 100% of the game code is my own.", {})]],
        size=15, colour=WHITE, anchor=MSO_ANCHOR.MIDDLE)

    # ================= 6. System design =================
    s = new_slide(deck, "System design and code structure", number=6, notes=(
        "The code is split into three layers. board.py holds only the rules, ai.py holds the "
        "search, and main.py holds the graphics, so the AI can be tested without a window. The "
        "core is this chance node: for every place the wind could put the piece, it plays the "
        "piece, scores the result, undoes it, and adds the score weighted by its probability. "
        "The tree alternates MAX, chance, MIN, chance. At the depth limit a heuristic scores every "
        "line of four on the board."))
    layers = [("main.py", "Pygame UI: menus, drawing, animation, async game loop"),
              ("ai.py", "Expectiminimax search, heuristic evaluation, agents"),
              ("board.py", "Rules: drop, wind outcomes + probabilities, win check"),
              ("config.py  |  tools/", "Settings  |  tests, experiments, screenshots")]
    for index, (name, role) in enumerate(layers):
        y = 1.6 + index * 1.15
        add_box(s, 0.6, y, 5.3, 0.95, fill=NAVY if index < 3 else CARD)
        add_text(s, 0.85, y + 0.1, 4.9, 0.35, name, size=16, bold=True, font=CODE_FONT,
                 colour=YELLOW if index < 3 else INK)
        add_text(s, 0.85, y + 0.48, 4.9, 0.4, role, size=12,
                 colour="E2E8F0" if index < 3 else MUTED)
    add_text(s, 0.6, 6.25, 5.3, 0.5, "Tree: MAX (AI) > CHANCE (die) > MIN (opponent) > CHANCE ...",
             size=12, bold=True, colour=BLUE)
    code = [
        "def chance_node_value(self, board, aimed, mover, depth):",
        "    expected = 0.0",
        "    for landing, prob in self.get_outcomes(board, aimed):",
        "        row = drop_piece(board, landing, mover)",
        "        if is_winning_placement(board, row, landing, mover):",
        "            value = +/- WIN_SCORE * depth",
        "        elif depth == 1:",
        "            value = evaluate_board(board, self.ai_player)",
        "        else:   # MAX or MIN node for the next player",
        "            value = self.decision_node_value(",
        "                        board, other(mover), depth - 1)",
        "        remove_piece(board, row, landing)   # undo",
        "        expected += prob * value",
        "    return expected",
    ]
    add_box(s, 6.2, 1.6, 6.5, 4.55, fill=SLATE)
    add_text(s, 6.45, 1.8, 6.1, 4.2, code, size=11.5, font=CODE_FONT, colour="E2E8F0", spacing=1)
    add_text(s, 6.2, 6.25, 6.5, 0.6,
             "Heuristic: +5 per open three, +2 per open two, +3 per centre piece (minus the "
             "same for the opponent)", size=12, colour=MUTED)

    # ================= 7. Challenges =================
    s = new_slide(deck, "Key challenges and how I solved them", number=7, notes=(
        "Four main challenges. First, speed: chance nodes multiply the tree, so I undo moves "
        "instead of copying boards and cache positions I've already scored, which keeps the Hard AI "
        "at about a tenth of a second. Second, the browser froze while the AI thought, which "
        "I fixed with an async loop that draws a thinking message first. Third, blocked gusts "
        "could double-count probabilities, so outcomes landing in the same column are merged. "
        "Fourth, I wanted the AI's reasoning to be visible, hence the analysis chart."))
    ms_hard = "~0.16 s"
    for row in effort:
        if row["depth"] == "4" and row["position"] == "mid-game":
            ms_hard = "%.2f s" % (float(row["ms"]) / 1000)
    challenges = [
        ("Search too slow", "Chance nodes triple the branching factor",
         "Undo moves instead of copying the board; cache repeated positions",
         "Hard AI: %s per move" % ms_hard),
        ("Browser froze", "A long search blocks the web page",
         "Async game loop; a 'thinking' frame is drawn before searching",
         "Smooth in pygbag"),
        ("Blocked gusts", "Edge or full columns broke the probabilities",
         "Merge outcomes that land in the same column",
         "Probabilities always sum to 1 (unit test)"),
        ("Invisible AI", "Players can't see why the AI moved",
         "Live bar chart of the value of every column",
         "Reasoning shown on screen"),
    ]
    add_text(s, 0.95, 1.55, 3, 0.3, "CHALLENGE", size=11, bold=True, colour=MUTED)
    add_text(s, 4.6, 1.55, 4, 0.3, "SOLUTION", size=11, bold=True, colour=MUTED)
    add_text(s, 9.55, 1.55, 3, 0.3, "RESULT", size=11, bold=True, colour=MUTED)
    for index, (name, problem, fix, outcome) in enumerate(challenges):
        y = 1.95 + index * 1.2
        add_box(s, 0.6, y, 12.1, 1.05)
        add_piece(s, 0.8, y + 0.28, 0.5, RED if index % 2 == 0 else YELLOW, str(index + 1),
                  text_colour=WHITE if index % 2 == 0 else INK, size=14)
        add_text(s, 1.5, y + 0.15, 2.9, 0.4, name, size=16, bold=True)
        add_text(s, 1.5, y + 0.53, 2.9, 0.45, problem, size=12, colour=MUTED)
        add_text(s, 4.6, y + 0.15, 4.7, 0.8, fix, size=14, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, 9.55, y + 0.15, 3.0, 0.8, outcome, size=14, bold=True, colour=GREEN,
                 anchor=MSO_ANCHOR.MIDDLE)

    # ================= 8. Testing & results =================
    s = new_slide(deck, "Testing and results", number=8, notes=(
        "I tested in two ways. Twelve unit tests check the rules, the probabilities, and that the "
        "AI takes wins and blocks threats. Then I ran %d games for each pairing of AIs, "
        "alternating who goes first and using fixed dice seeds so results can be repeated. Any "
        "search crushes random play, and looking deeper wins more often. The surprising result "
        "is the last row: a Minimax that ignores the dice did just as well. Modelling the dice "
        "changed the chosen move in about %d%% of positions, but with two thirds calm wind, "
        "luck evens out those differences. That is an honest finding I discuss in the report."
        % (games_each, round(100 - float(agreement["agreement_percent"])))))
    if results:
        chart_data = CategoryChartData()
        chart_data.categories = SHORT_LABELS[:len(results)]
        chart_data.add_series("First-named AI wins", [int(r["wins_a"]) for r in results])
        chart_data.add_series("Draws", [int(r["draws"]) for r in results])
        chart_data.add_series("Second-named AI wins", [int(r["wins_b"]) for r in results])
        frame = s.shapes.add_chart(XL_CHART_TYPE.BAR_STACKED_100, Inches(0.6), Inches(1.5),
                                   Inches(8.0), Inches(5.3), chart_data)
        chart = frame.chart
        chart.has_legend = True
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(11)
        chart.legend.font.color.rgb = rgb(MUTED)
        chart.has_title = True
        chart.chart_title.text_frame.text = "Head-to-head: %d games per pairing" % games_each
        title_run = chart.chart_title.text_frame.paragraphs[0].runs[0]
        title_run.font.size = Pt(14)
        title_run.font.bold = True
        title_run.font.color.rgb = rgb(INK)
        category_axis = chart.category_axis
        category_axis.reverse_order = True
        category_axis.tick_labels.font.size = Pt(11)
        category_axis.tick_labels.font.color.rgb = rgb(INK)
        category_axis.format.line.color.rgb = rgb("CBD5E1")
        value_axis = chart.value_axis
        value_axis.has_major_gridlines = False
        value_axis.visible = False
        plot = chart.plots[0]
        plot.gap_width = 45
        for series, colour in zip(plot.series, (GREEN, "94A3B8", RED)):
            series.format.fill.solid()
            series.format.fill.fore_color.rgb = rgb(colour)
        labels = plot.series[0].data_labels
        labels.show_value = True
        labels.position = XL_LABEL_POSITION.CENTER
        labels.font.size = Pt(11)
        labels.font.bold = True
        labels.font.color.rgb = rgb(WHITE)
    stats = [("12 / 12", "unit tests pass (rules + AI)")]
    for row in results:
        if row["agent_a"] == "Expectiminimax d4" and row["agent_b"].startswith("Greedy"):
            stats.append(("%d%%" % round(float(row["win_rate_a"])),
                          "Hard AI (depth 4) win rate vs Greedy (depth 1)"))
    for row in results:
        if row["agent_b"].startswith("Minimax"):
            stats.append(("%d vs %d" % (int(row["wins_a"]), int(row["wins_b"])),
                          "Expectiminimax vs no-dice Minimax: different move in %d%% of "
                          "positions, same win rate" %
                          round(100 - float(agreement["agreement_percent"]))))
    stats.append((ms_hard, "Hard AI thinking time per move (desktop)"))
    for index, (big, small) in enumerate(stats[:4]):
        y = 1.6 + index * 1.3
        add_box(s, 8.9, y, 3.8, 1.15, fill=NAVY if index == 1 else CARD)
        add_text(s, 9.15, y + 0.1, 3.4, 0.55, big, size=28, bold=True, font=HEAD_FONT,
                 colour=YELLOW if index == 1 else BLUE)
        add_text(s, 9.15, y + 0.66, 3.4, 0.45, small, size=11,
                 colour="E2E8F0" if index == 1 else MUTED)

    # ================= 9. Publishing =================
    s = new_slide(deck, "Publishing: play it in any browser", number=9, notes=(
        "To publish, pygbag compiles the Python game to WebAssembly. I zip the web build and "
        "upload it to itch.io as an HTML5 game, which gives a public link that works on any "
        "computer with no install. The source code is on GitHub. I'll now switch to the live "
        "demo using this link."))
    steps = [("1", "Build", "pygbag --build game"), ("2", "Package", "zip build/web"),
             ("3", "Upload", "itch.io  >  HTML5 game"), ("4", "Play", "Public link, no install")]
    for index, (number, name, detail) in enumerate(steps):
        x = 0.6 + index * 1.88
        add_box(s, x, 1.65, 1.7, 2.1)
        add_piece(s, x + 0.55, 1.85, 0.6, RED if index % 2 == 0 else YELLOW, number,
                  text_colour=WHITE if index % 2 == 0 else INK)
        add_text(s, x + 0.1, 2.6, 1.5, 0.4, name, size=16, bold=True, align=PP_ALIGN.CENTER)
        add_text(s, x + 0.1, 3.0, 1.5, 0.7, detail, size=11, colour=MUTED, align=PP_ALIGN.CENTER,
                 font=CODE_FONT if index < 2 else BODY_FONT)
    add_box(s, 0.6, 4.1, 7.4, 1.25, fill=NAVY)
    add_text(s, 0.9, 4.2, 7.0, 0.35, "PLAY THE GAME", size=11, bold=True, colour=SKY)
    add_text(s, 0.9, 4.58, 7.0, 0.6, config.PUBLISHED_URL, size=14, bold=True, colour=WHITE,
             font=CODE_FONT)
    add_box(s, 0.6, 5.55, 7.4, 1.15)
    add_text(s, 0.9, 5.65, 7.0, 0.35, "SOURCE CODE", size=11, bold=True, colour=MUTED)
    add_text(s, 0.9, 6.0, 7.0, 0.6, config.REPO_URL, size=14, bold=True, font=CODE_FONT)
    add_picture(s, os.path.join(SHOTS, "04_game_over.png"), 8.35, 1.65, 4.35)
    add_text(s, 8.35, 5.0, 4.35, 0.6, "Same Python code runs on desktop and in the browser.",
             size=12, colour=MUTED)

    # ================= 10. Conclusion =================
    s = new_slide(deck, "Conclusion and future improvements", dark=True, number=10, notes=(
        "To conclude: the game is complete, published, and the AI does what the brief asks: it "
        "evaluates every consequence of every move, weighted by probability, and picks the one "
        "closest to victory. The experiments show that both depth and modelling chance improve "
        "play. In future I'd add pruning for chance nodes so it can search deeper, compare against "
        "Monte Carlo Tree Search, and add online multiplayer and sound. Thank you."))
    add_text(s, 0.6, 1.6, 5.8, 0.5, "What I achieved", size=22, bold=True, font=HEAD_FONT,
             colour=YELLOW)
    add_text(s, 0.6, 2.25, 5.8, 3.8, [
        "A complete, published two-player game with chance",
        "Expectiminimax AI that weighs every move, every die roll and every reply",
        "Three difficulties, two-player and AI vs AI modes, live AI analysis",
        "Tested: 12 unit tests + %s AI-vs-AI games" % "{:,}".format(total_games),
    ], size=16, colour=WHITE, bullets=True, spacing=12)
    add_box(s, 6.9, 1.6, 5.8, 3.9, fill=SLATE)
    add_text(s, 7.2, 1.8, 5.2, 0.5, "Future improvements", size=22, bold=True, font=HEAD_FONT,
             colour=SKY)
    add_text(s, 7.2, 2.45, 5.2, 3.8, [
        "Star1/Star2 pruning for chance nodes, to search deeper",
        "Compare with Monte Carlo Tree Search",
        "Tune the heuristic weights automatically (self-play)",
        "Online multiplayer, sound effects, touch-friendly mobile layout",
        "Adjustable wind strength as a difficulty option",
    ], size=15, colour="E2E8F0", bullets=True, spacing=10)
    add_text(s, 0.6, 6.0, 6, 0.6, "Thank you!", size=28, bold=True, font=HEAD_FONT, colour=WHITE)

    os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)
    deck.save(OUTPUT)
    print("saved", OUTPUT)


if __name__ == "__main__":
    build()
