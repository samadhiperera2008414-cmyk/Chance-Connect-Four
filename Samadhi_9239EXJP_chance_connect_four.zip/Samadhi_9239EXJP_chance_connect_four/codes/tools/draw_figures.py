# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  draw_figures.py
#  Draws the wireframes and diagrams used in the report
#  (report/figures/*.png). Uses Pillow.
#  Run from the project folder:   python tools/draw_figures.py
# =====================================================================

import os

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT = os.path.join(HERE, "..", "report", "figures")
FONT_PATH = "/System/Library/Fonts/Supplemental/Arial.ttf"
BOLD_PATH = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"

LINE = (71, 85, 105)
FILL = (241, 245, 249)
DARK = (15, 23, 42)
NOTE = (37, 99, 235)


# ---------------------------------------------------------------------
# font - loads Arial at a size (falls back to Pillow's default font).
# Parameters: size - pixel size;  bold - True for bold
# ---------------------------------------------------------------------
def font(size, bold=False):
    try:
        return ImageFont.truetype(BOLD_PATH if bold else FONT_PATH, size)
    except OSError:
        return ImageFont.load_default()


# ---------------------------------------------------------------------
# box - draws a labelled rectangle.
# Parameters:
#   draw         - ImageDraw object
#   xy           - (left, top, right, bottom)
#   label        - text in the centre ("" for none)
#   size, bold   - label font
#   fill, dashed - background colour / dashed outline flag
# ---------------------------------------------------------------------
def box(draw, xy, label="", size=22, bold=False, fill=FILL, radius=10):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=LINE, width=3)
    if label:
        cx, cy = (xy[0] + xy[2]) / 2, (xy[1] + xy[3]) / 2
        draw.multiline_text((cx, cy), label, fill=DARK, font=font(size, bold), anchor="mm",
                            align="center", spacing=6)


# ---------------------------------------------------------------------
# marker - draws a numbered blue circle on an element and adds the
# matching line to a legend on the right of the wireframe.
# Parameters:
#   draw      - ImageDraw object
#   number    - marker number
#   target_xy - (x, y) where the marker sits on the wireframe
#   text      - legend text
#   legend_x  - x position of the legend column
# ---------------------------------------------------------------------
def marker(draw, number, target_xy, text, legend_x=1010):
    x, y = target_xy
    draw.ellipse((x - 17, y - 17, x + 17, y + 17), fill=NOTE)
    draw.text((x, y), str(number), fill="white", font=font(20, True), anchor="mm")
    legend_y = 60 + (number - 1) * 52
    draw.ellipse((legend_x, legend_y - 17, legend_x + 34, legend_y + 17), fill=NOTE)
    draw.text((legend_x + 17, legend_y), str(number), fill="white", font=font(20, True), anchor="mm")
    draw.text((legend_x + 46, legend_y), text, fill=DARK, font=font(21), anchor="lm")


# ---------------------------------------------------------------------
# menu_wireframe - wireframe of the title screen.
# Parameters: none.  Saves wireframe_menu.png
# ---------------------------------------------------------------------
def menu_wireframe():
    image = Image.new("RGB", (1360, 760), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((20, 20, 980, 740), outline=DARK, width=4)
    box(draw, (200, 50, 800, 120), "GAME TITLE", 34, True)
    box(draw, (230, 135, 770, 170), "Subtitle / tagline", 18)
    for i in range(7):
        draw.ellipse((360 + i * 42, 185, 390 + i * 42, 215), outline=LINE, width=3)
    box(draw, (60, 240, 470, 640), "HOW TO PLAY\n\nRules text\n(wind die faces 1 / 2-5 / 6)", 22)
    for i, label in enumerate(["vs AI - Easy", "vs AI - Medium", "vs AI - Hard",
                               "Two Players", "Watch AI vs AI"]):
        box(draw, (520, 240 + i * 82, 930, 306 + i * 82), label, 22, True)
    box(draw, (250, 680, 750, 715), "Student name  |  Student ID  |  module", 18)
    marker(draw, 1, (930, 240), "Choose a mode / difficulty")
    marker(draw, 2, (60, 240), "Rules + wind die faces")
    marker(draw, 3, (250, 697), "Student name and ID")
    image.save(os.path.join(OUTPUT, "wireframe_menu.png"))


# ---------------------------------------------------------------------
# game_wireframe - wireframe of the main game screen.
# Parameters: none.  Saves wireframe_game.png
# ---------------------------------------------------------------------
def game_wireframe():
    image = Image.new("RGB", (1360, 760), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((20, 20, 980, 740), outline=DARK, width=4)
    box(draw, (50, 35, 420, 80), "Title", 24, True)
    box(draw, (640, 35, 950, 80), "Name | ID | keys", 18)
    for column in range(7):
        x = 90 + column * 80
        draw.text((x, 118), "%", fill=LINE, font=font(18), anchor="mm")
    draw.ellipse((210, 135, 270, 185), outline=LINE, width=3)
    draw.rounded_rectangle((50, 200, 610, 680), radius=14, outline=DARK, width=4, fill=(219, 234, 254))
    for row in range(6):
        for column in range(7):
            x, y = 90 + column * 80, 240 + row * 80
            draw.ellipse((x - 30, y - 30, x + 30, y + 30), outline=LINE, width=3, fill="white")
    box(draw, (650, 100, 950, 215), "PLAYERS + WINS", 20, True)
    box(draw, (650, 230, 950, 410), "WIND DIE\n[ die ]\nwhat the wind did", 20)
    box(draw, (650, 425, 950, 700), "AI ANALYSIS\n\nbar per column\n(tallest = best)\n\npositions searched, time", 19)
    marker(draw, 1, (40, 118), "Landing odds on hover")
    marker(draw, 2, (290, 160), "Ghost piece over column")
    marker(draw, 3, (50, 200), "6 x 7 board (click column)")
    marker(draw, 4, (950, 100), "Players, turn and wins")
    marker(draw, 5, (950, 230), "Wind die + what happened")
    marker(draw, 6, (950, 425), "AI expected-value chart")
    image.save(os.path.join(OUTPUT, "wireframe_game.png"))


# ---------------------------------------------------------------------
# triangle - draws a MAX (pointing up) or MIN (pointing down) node.
# Parameters: draw, centre (x, y), up (True = MAX), label
# ---------------------------------------------------------------------
def triangle(draw, centre, up, label):
    x, y = centre
    if up:
        points = [(x, y - 34), (x - 38, y + 26), (x + 38, y + 26)]
    else:
        points = [(x, y + 34), (x - 38, y - 26), (x + 38, y - 26)]
    draw.polygon(points, fill=FILL, outline=DARK)
    draw.line(points + [points[0]], fill=DARK, width=3)
    draw.text((x, y + (4 if up else -4)), label, fill=DARK, font=font(17, True), anchor="mm")


# ---------------------------------------------------------------------
# tree_diagram - the expectiminimax tree for one AI move.
# Parameters: none.  Saves expectiminimax_tree.png
# ---------------------------------------------------------------------
def tree_diagram():
    image = Image.new("RGB", (1400, 560), "white")
    draw = ImageDraw.Draw(image)
    root = (700, 60)
    chances = [(260, 210), (700, 210), (1140, 210)]
    aim_labels = ["aim col 3", "aim col 4", "aim col 5"]
    for (cx, cy), label in zip(chances, aim_labels):
        draw.line([root, (cx, cy)], fill=LINE, width=3)
        if cx == root[0]:
            draw.text((cx + 14, (root[1] + cy) / 2), label, fill=NOTE, font=font(19, True), anchor="lm")
        else:
            draw.text(((root[0] + cx) / 2 + (-40 if cx < root[0] else 40), (root[1] + cy) / 2 - 38),
                      label, fill=NOTE, font=font(19, True), anchor="mm")
    for (cx, cy) in chances:
        for k, (dx, probability, land) in enumerate([(-130, "1/6", "lands 2"), (0, "4/6", "lands 3"),
                                                     (130, "1/6", "lands 4")]):
            mx, my = cx + dx, 380
            draw.line([(cx, cy), (mx, my)], fill=LINE, width=3)
            draw.text(((cx + mx) / 2 + (-22 if dx < 0 else 22 if dx > 0 else 26), (cy + my) / 2),
                      probability, fill=DARK, font=font(18, True), anchor="mm")
            triangle(draw, (mx, my), False, "MIN")
            draw.line([(mx, my + 34), (mx - 25, 470)], fill=LINE, width=2)
            draw.line([(mx, my + 34), (mx + 25, 470)], fill=LINE, width=2)
            draw.text((mx, 490), "...", fill=LINE, font=font(22, True), anchor="mm")
    for (cx, cy) in chances:
        draw.ellipse((cx - 34, cy - 34, cx + 34, cy + 34), fill=(254, 249, 195), outline=DARK, width=3)
        draw.text((cx, cy), "CHANCE", fill=DARK, font=font(14, True), anchor="mm")
    triangle(draw, root, True, "MAX")
    draw.text((20, 530), "MAX = AI picks the highest value.   CHANCE = average weighted by the "
              "wind-die probabilities.   MIN = opponent picks the lowest value.",
              fill=DARK, font=font(19), anchor="lm")
    image.save(os.path.join(OUTPUT, "expectiminimax_tree.png"))


# ---------------------------------------------------------------------
# state_diagram - how the game moves between its states.
# Parameters: none.  Saves state_flow.png
# ---------------------------------------------------------------------
def state_diagram():
    image = Image.new("RGB", (1400, 300), "white")
    draw = ImageDraw.Draw(image)
    states = [("menu", 20), ("turn", 250), ("thinking\n(AI only)", 480), ("rolling\n(die anim)", 710),
              ("moving\n(gust + fall)", 940), ("game_over", 1170)]
    for label, x in states:
        box(draw, (x, 90, x + 200, 190), label, 22, True)
    for (_, x), (_, next_x) in zip(states, states[1:]):
        draw.line([(x + 200, 140), (next_x, 140)], fill=DARK, width=3)
        draw.polygon([(next_x, 140), (next_x - 14, 132), (next_x - 14, 148)], fill=DARK)
    # human skips thinking: turn -> rolling
    draw.line([(350, 90), (350, 45), (810, 45), (810, 90)], fill=NOTE, width=3)
    draw.polygon([(810, 90), (802, 76), (818, 76)], fill=NOTE)
    draw.text((580, 30), "human clicks a column", fill=NOTE, font=font(18, True), anchor="mm")
    # no winner: moving -> turn
    draw.line([(1040, 190), (1040, 250), (350, 250), (350, 190)], fill=NOTE, width=3)
    draw.polygon([(350, 190), (342, 204), (358, 204)], fill=NOTE)
    draw.text((695, 268), "no win yet: switch player", fill=NOTE, font=font(18, True), anchor="mm")
    image.save(os.path.join(OUTPUT, "state_flow.png"))


if __name__ == "__main__":
    os.makedirs(OUTPUT, exist_ok=True)
    menu_wireframe()
    game_wireframe()
    tree_diagram()
    state_diagram()
    print("figures saved to", OUTPUT)
