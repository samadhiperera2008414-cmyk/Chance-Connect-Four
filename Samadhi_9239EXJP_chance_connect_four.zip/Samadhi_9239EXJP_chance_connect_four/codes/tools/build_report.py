# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  build_report.py
#  Generates the project report (Word .docx) from the config, figures,
#  screenshots and experiment results.  Sections required by the brief:
#  1 Introduction, 2 Design (wireframes), 3 Implementation (sample input
#  and output), 4 Conclusion - max 5 pages excluding the cover.
#  Run from the project folder:   python tools/build_report.py
# =====================================================================

import csv
import io
import os
import sys
import unittest
from contextlib import redirect_stderr

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "game"))
sys.path.insert(0, HERE)
import ai              # noqa: E402
import board as rules  # noqa: E402
import config          # noqa: E402

FIGURES = os.path.join(ROOT, "report", "figures")
SHOTS = os.path.join(ROOT, "backup", "screenshots")
RESULTS = os.path.join(ROOT, "results")
FILE_TITLE = "%s_ChanceConnectFour" % config.STUDENT_NAME.replace(" ", "")
OUTPUT = os.path.join(ROOT, "report", FILE_TITLE + ".docx")

NAVY = RGBColor(0x0F, 0x17, 0x2A)
BLUE = RGBColor(0x25, 0x63, 0xEB)
GREY = RGBColor(0x64, 0x74, 0x8B)


# ---------------------------------------------------------------------
# load_csv - reads a CSV from the results folder.
# Parameters: name - file name.  Returns: list of dicts ([] if missing)
# ---------------------------------------------------------------------
def load_csv(name):
    path = os.path.join(RESULTS, name)
    if not os.path.exists(path):
        return []
    with open(path) as handle:
        return list(csv.DictReader(handle))


# ---------------------------------------------------------------------
# set_cell_shading - gives a table cell a background colour.
# Parameters: cell - docx table cell;  hex_colour - "RRGGBB"
# ---------------------------------------------------------------------
def set_cell_shading(cell, hex_colour):
    properties = cell._tc.get_or_add_tcPr()
    shading = OxmlElement("w:shd")
    shading.set(qn("w:val"), "clear")
    shading.set(qn("w:color"), "auto")
    shading.set(qn("w:fill"), hex_colour)
    properties.append(shading)


# ---------------------------------------------------------------------
# add_page_number_field - inserts a PAGE field into a paragraph.
# Parameters: paragraph - the docx paragraph to add it to
# ---------------------------------------------------------------------
def add_page_number_field(paragraph):
    run = paragraph.add_run()
    for kind, text in (("begin", None), (None, "PAGE"), ("end", None)):
        if kind:
            element = OxmlElement("w:fldChar")
            element.set(qn("w:fldCharType"), kind)
        else:
            element = OxmlElement("w:instrText")
            element.set(qn("xml:space"), "preserve")
            element.text = text
        run._r.append(element)


# ---------------------------------------------------------------------
# heading - adds a numbered section heading in the report style.
# Parameters: document, text, level (1 or 2)
# ---------------------------------------------------------------------
def heading(document, text, level=1):
    paragraph = document.add_heading(text, level=level)
    for run in paragraph.runs:
        run.font.color.rgb = NAVY if level == 1 else BLUE
        run.font.name = "Arial"
        run.font.size = Pt(15 if level == 1 else 12)
    paragraph.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    paragraph.paragraph_format.space_after = Pt(3)
    return paragraph


# ---------------------------------------------------------------------
# para - adds a body paragraph; **bold** segments are made bold.
# Parameters: document, text, style (optional docx style name)
# ---------------------------------------------------------------------
def para(document, text, style=None):
    paragraph = document.add_paragraph(style=style)
    for index, part in enumerate(text.split("**")):
        run = paragraph.add_run(part)
        run.bold = index % 2 == 1
    paragraph.paragraph_format.space_after = Pt(4)
    return paragraph


# ---------------------------------------------------------------------
# code_block - adds monospaced text (code or console output) in a box.
# Parameters: document, lines - list of strings, size - font size
# ---------------------------------------------------------------------
def code_block(document, lines, size=8.5):
    table = document.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]
    set_cell_shading(cell, "F1F5F9")
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run("\n".join(lines))
    run.font.name = "Courier New"
    run.font.size = Pt(size)
    document.add_paragraph().paragraph_format.space_after = Pt(0)


# ---------------------------------------------------------------------
# caption - adds an italic figure/table caption.
# Parameters: document, text
# ---------------------------------------------------------------------
def caption(document, text):
    paragraph = document.add_paragraph()
    run = paragraph.add_run(text)
    run.italic = True
    run.font.size = Pt(9)
    run.font.color.rgb = GREY
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_after = Pt(6)


# ---------------------------------------------------------------------
# picture - adds a centred picture.
# Parameters: document, path, width_cm
# ---------------------------------------------------------------------
def picture(document, path, width_cm):
    document.add_picture(path, width=Cm(width_cm))
    document.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    document.paragraphs[-1].paragraph_format.space_after = Pt(2)


# ---------------------------------------------------------------------
# pictures_side_by_side - two pictures in a borderless 2-column table.
# Parameters: document, paths (two paths), width_cm (each)
# ---------------------------------------------------------------------
def pictures_side_by_side(document, paths, width_cm):
    table = document.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for cell, path in zip(table.rows[0].cells, paths):
        paragraph = cell.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.add_run().add_picture(path, width=Cm(width_cm))


# ---------------------------------------------------------------------
# data_table - adds a simple table with a shaded header row.
# Parameters: document, header (list), rows (list of lists), widths_cm
# ---------------------------------------------------------------------
def data_table(document, header, rows, widths_cm):
    table = document.add_table(rows=1 + len(rows), cols=len(header))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for row_index, values in enumerate([header] + rows):
        for column_index, value in enumerate(values):
            cell = table.rows[row_index].cells[column_index]
            cell.width = Cm(widths_cm[column_index])
            cell.text = ""
            run = cell.paragraphs[0].add_run(str(value))
            run.font.size = Pt(9)
            run.bold = row_index == 0
            cell.paragraphs[0].paragraph_format.space_after = Pt(0)
            if row_index == 0:
                set_cell_shading(cell, "E2E8F0")
    return table


# ---------------------------------------------------------------------
# sample_ai_run - produces a real sample input/output of the AI.
# Parameters: none
# Returns: list of text lines (board, then the AI's analysis)
# ---------------------------------------------------------------------
def sample_ai_run():
    lookup = {".": rules.EMPTY, "X": rules.PLAYER_ONE, "O": rules.PLAYER_TWO}
    rows = [". . . . . . .", ". . . . . . .", ". . . . . . .",
            ". X . . . . .", ". X . . . O .", ". X . O O O X"]
    board = [[lookup[symbol] for symbol in row.split()] for row in rows]
    lines = ["INPUT  (X = human, O = AI to move, Hard AI = depth 4)", ""]
    lines += ["  " + line for line in rules.board_to_text(board).split("\n")]
    lines += ["", "OUTPUT"]
    result = ai.ExpectiminimaxSearch(rules.PLAYER_TWO, 4).find_best_move(board)
    for column in range(rules.COLS):
        if column in result.column_scores:
            outcomes = ", ".join("col %d: %.0f%%" % (landing + 1, probability * 100)
                                 for landing, probability in rules.get_chance_outcomes(board, column))
            mark = "   <-- chosen" if column == result.best_column else ""
            lines.append("  aim col %d  expected value %+10.1f   (lands %s)%s" % (
                column + 1, result.column_scores[column], outcomes, mark))
    lines.append("  positions searched: {:,}   time: {:.3f} s".format(
        result.nodes_searched, result.seconds))
    return lines, result


# ---------------------------------------------------------------------
# unit_test_summary - runs the unit tests and returns their summary line.
# Parameters: none.  Returns: (tests run, all passed?)
# ---------------------------------------------------------------------
def unit_test_summary():
    import test_game
    suite = unittest.defaultTestLoader.loadTestsFromModule(test_game)
    with redirect_stderr(io.StringIO()):
        outcome = unittest.TextTestRunner(stream=io.StringIO()).run(suite)
    return outcome.testsRun, outcome.wasSuccessful()


# ---------------------------------------------------------------------
# build - writes the whole report.
# Parameters: none
# ---------------------------------------------------------------------
def build():
    results = load_csv("head_to_head.csv")
    effort = load_csv("search_effort.csv")
    agreement = (load_csv("agreement.csv") or [{"agreement_percent": "0", "positions": "0"}])[0]
    games_each = int(results[0]["games"]) if results else 0
    tests_run, tests_ok = unit_test_summary()
    sample_lines, sample_result = sample_ai_run()

    document = Document()
    normal = document.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)
    section = document.sections[0]
    section.page_height, section.page_width = Cm(29.7), Cm(21.0)
    for side in ("left_margin", "right_margin"):
        setattr(section, side, Cm(2.0))
    section.top_margin = section.bottom_margin = Cm(1.8)

    # ---------------- Cover ----------------
    for _ in range(6):
        document.add_paragraph()
    for text, size, colour, bold in [
            ("5FTC2067 Artificial Intelligence Principles - Mini Project 2025-26", 12, BLUE, True),
            ("Chance Connect Four", 34, NAVY, True),
            ("A two-player game of skill and luck with an Expectiminimax AI", 14, GREY, False)]:
        paragraph = document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = paragraph.add_run(text)
        run.font.size = Pt(size)
        run.font.color.rgb = colour
        run.bold = bold
        run.font.name = "Arial"
    document.add_paragraph()
    picture(document, os.path.join(SHOTS, "04_game_over.png"), 11)
    document.add_paragraph()
    for label, value in [("Student name", config.STUDENT_NAME), ("Student ID", config.STUDENT_ID),
                         ("Published game", config.PUBLISHED_URL),
                         ("Source code", config.REPO_URL)]:
        paragraph = document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.space_after = Pt(2)
        run = paragraph.add_run(label + ":  ")
        run.font.color.rgb = GREY
        paragraph.add_run(value).bold = True

    # Main body in a new section so the cover has no page number
    body = document.add_section(WD_SECTION.NEW_PAGE)
    body.footer.is_linked_to_previous = False
    footer = body.footer.paragraphs[0]
    footer.text = "%s  |  %s  |  Chance Connect Four  |  page " % (config.STUDENT_NAME,
                                                                    config.STUDENT_ID)
    add_page_number_field(footer)
    for run in footer.runs:
        run.font.size = Pt(8)
        run.font.color.rgb = GREY
    sect_pr = body._sectPr
    page_numbers = OxmlElement("w:pgNumType")
    page_numbers.set(qn("w:start"), "1")
    sect_pr.append(page_numbers)
    first_footer = document.sections[0].footer
    first_footer.is_linked_to_previous = False

    # ---------------- 1 Introduction ----------------
    heading(document, "1  Introduction")
    para(document,
         "The brief asks for a two-player game that involves chance, in which the computer "
         "“evaluates all the possible consequences of each move and chooses the one that is "
         "closest to victory”. This describes **Expectiminimax**, the extension of Minimax to "
         "games with random events (Russell and Norvig, 2021, ch. 5).")
    para(document,
         "**Chance Connect Four** keeps the familiar 6 x 7 Connect Four board but adds a **wind "
         "die**. After a player chooses a column, a six-sided die is rolled: a 1 blows the piece "
         "one column left, a 6 blows it one column right, and 2-5 means calm air. A familiar game "
         "keeps the rules quick to learn, while the die means no move is ever certain. The AI "
         "therefore has to reason about probabilities and cannot simply calculate a forced win.")
    para(document,
         "The objectives were to (1) build a complete, attractive game in Python, (2) implement "
         "Expectiminimax with three difficulty levels, (3) publish the game so it can be played "
         "in a web browser, and (4) evaluate the AI experimentally against other methods. The "
         "game targets casual players who want short matches, and students of AI, because it "
         "shows the AI's evaluation of every column on screen.")

    # ---------------- 2 Design ----------------
    heading(document, "2  Design")
    heading(document, "2.1  Rules and chance model", 2)
    para(document,
         "Players alternate turns and the first to connect four in any direction wins; a full "
         "board is a draw. Because the die decides the drift, each aimed column has up to three "
         "outcomes. If a gust would push the piece off the board or into a full column, it lands "
         "in the aimed column instead, and the two probabilities are **merged** so they always "
         "sum to 1:")
    data_table(document, ["Die face", "Effect", "Probability", "Edge column (e.g. col 1)"],
               [["1", "1 column left", "1/6 (17%)", "blocked: stays, merged"],
                ["2, 3, 4, 5", "lands where aimed", "4/6 (67%)", "5/6 (83%) incl. blocked gust"],
                ["6", "1 column right", "1/6 (17%)", "1/6 (17%)"]], [2.5, 4.0, 3.0, 5.5])
    caption(document, "Table 1 - Wind die outcomes")

    heading(document, "2.2  Wireframes", 2)
    para(document,
         "Two screens were designed before coding. The title screen holds the rules and mode "
         "buttons. The game screen keeps the board on the left and a three-card information "
         "panel on the right. A key design decision was to make the chance **visible**: hovering "
         "over a column shows the landing probabilities, and the AI panel shows the expected "
         "value of every column.")
    pictures_side_by_side(document, [os.path.join(FIGURES, "wireframe_menu.png"),
                                     os.path.join(FIGURES, "wireframe_game.png")], 8.2)
    caption(document, "Figure 1 - Wireframes: title screen (left) and game screen (right)")

    heading(document, "2.3  System design", 2)
    para(document,
         "The code is split into layers so the rules and the AI can be tested without graphics: "
         "**board.py** (rules, wind outcomes, win detection), **ai.py** (search, evaluation, "
         "agents), **main.py** (Pygame interface) and **config.py** (student details, "
         "difficulty depths). The tools folder holds the unit tests, experiments and the "
         "slide/report generators. The interface is a small state machine (Figure 2). Its "
         "main loop is asynchronous, so the same file runs on the desktop and in the browser.")
    picture(document, os.path.join(FIGURES, "state_flow.png"), 15.5)
    caption(document, "Figure 2 - Game state flow")

    heading(document, "2.4  AI design: Expectiminimax", 2)
    para(document,
         "The search tree alternates **MAX** nodes (the AI picks the highest value), **CHANCE** "
         "nodes (the probability-weighted average over the wind outcomes) and **MIN** nodes (the "
         "opponent is assumed to pick the lowest value). One ply is one move plus its die roll. "
         "Easy, Medium and Hard search 1, 2 and 4 plies. A win is worth 100,000 x the remaining "
         "depth, so quicker wins are preferred. At the depth limit, a heuristic scores all 69 "
         "possible lines of four: +5 for three of the AI's pieces with an empty cell, +2 for "
         "two with two empty cells, +3 per piece in the centre column, and the same amounts "
         "subtracted for the opponent.")
    picture(document, os.path.join(FIGURES, "expectiminimax_tree.png"), 14.5)
    caption(document, "Figure 3 - One level of the Expectiminimax tree for the AI's move")

    # ---------------- 3 Implementation ----------------
    heading(document, "3  Implementation")
    heading(document, "3.1  Core algorithm", 2)
    para(document,
         "The chance node below is the heart of the AI. Instead of copying the board for every "
         "branch, it places a piece, evaluates it and **undoes** the move. Decision nodes also "
         "cache positions they have already scored, because different wind outcomes often reach "
         "the same position. Every function in the project is preceded by comments explaining "
         "what it does and what each parameter is for.")
    code_block(document, [
        "def chance_node_value(self, board, aimed_column, mover, depth):",
        "    expected_value = 0.0",
        "    for landing_column, probability in self.get_outcomes(board, aimed_column):",
        "        row = rules.drop_piece(board, landing_column, mover)",
        "        if rules.is_winning_placement(board, row, landing_column, mover):",
        "            value = WIN_SCORE * depth if mover == self.ai_player else -WIN_SCORE * depth",
        "        elif rules.is_board_full(board):  value = 0",
        "        elif depth == 1:  value = evaluate_board(board, self.ai_player)",
        "        else:  value = self.decision_node_value(board, other(mover), depth - 1)",
        "        rules.remove_piece(board, row, landing_column)        # undo the move",
        "        expected_value += probability * value",
        "    return expected_value",
    ])

    heading(document, "3.2  Sample input and output", 2)
    para(document,
         "The sample below is real output from the AI. X has three pieces stacked in column 2, "
         "and O (the AI) has three in a row along the bottom. The AI scores every column by "
         "looking at every wind outcome, every reply and its own next move:")
    code_block(document, sample_lines, size=8)
    chosen = sample_result.best_column + 1
    if chosen == 3:
        explanation = (
            "The AI aims at column 3. A calm roll (4/6) completes its bottom row and wins at "
            "once. A left gust (1/6) drops the piece into column 2, which blocks X's threat "
            "instead. Only a right gust (1/6) wastes the move and leaves X able to win. Aiming "
            "at column 2 to block is scored much lower, because it gives up the immediate win "
            "and a gust could still let X through. Every option is an expected value over the "
            "dice, not a certainty.")
    else:
        explanation = ("The AI aims at column %d. Every option is scored as an expected value "
                       "over the dice, including the chance that a gust ruins a block or a "
                       "win." % chosen)
    para(document, explanation)
    pictures_side_by_side(document, [os.path.join(SHOTS, "03_wind_gust.png"),
                                     os.path.join(SHOTS, "05_ai_analysis.png")], 7.6)
    caption(document, "Figure 4 - In-game: a gust blowing a piece left (left); AI analysis "
                      "chart with the chosen column highlighted (right)")

    heading(document, "3.3  Testing and results", 2)
    para(document,
         "**Unit tests:** %d automated tests (Python unittest) check stacking, full columns, wind "
         "outcomes at the edges and next to full columns, that probabilities sum to 1, wins in "
         "all four directions, and that the AI takes a winning move, blocks a threat, prefers the "
         "centre and never changes the real board. Result: **%s**." %
         (tests_run, "all %d passed" % tests_run if tests_ok else "some failed"))
    para(document,
         "**Experiments:** each pair of agents played %d games. The first player alternated "
         "every game and the dice were seeded, so the results can be repeated "
         "(tools/experiments.py)." % games_each)
    rows = [[r["agent_a"], r["agent_b"], r["wins_a"], r["wins_b"], r["draws"],
             "%s%%" % r["win_rate_a"]] for r in results]
    data_table(document, ["Agent A", "Agent B", "A wins", "B wins", "Draws", "A win %"], rows,
               [4.3, 4.3, 1.6, 1.6, 1.4, 1.8])
    caption(document, "Table 2 - Head-to-head results (%d games per pairing)" % games_each)
    depth4 = [e for e in effort if e["depth"] == "4" and e["position"] == "mid-game"]
    depth5 = [e for e in effort if e["depth"] == "5" and e["position"] == "mid-game"]
    para(document,
         "Any look-ahead beats random play (96-98%%), and deeper search wins more often: depth 4 "
         "beats depth 1 in 68%% of games and depth 2 in 53%%. Chance keeps even weak players in "
         "the game, so no AI ever wins every game. The most interesting result is the last row. "
         "A Minimax of the same depth that **ignores the dice** won just as often. It chose a "
         "different column from Expectiminimax in %.0f%% of %s sampled positions, but with two "
         "thirds of rolls calm, those different choices were usually of similar quality, and "
         "the luck of later rolls outweighed the difference. Search cost grows about five times "
         "per ply: depth 4 examines %s positions in %s ms, and depth 5 examines %s in %s ms, "
         "which is why Hard stops at depth 4 to stay responsive in the browser." %
         (100 - float(agreement["agreement_percent"]), agreement["positions"],
          "{:,}".format(int(depth4[0]["nodes"])) if depth4 else "?",
          depth4[0]["ms"] if depth4 else "?",
          "{:,}".format(int(depth5[0]["nodes"])) if depth5 else "?",
          depth5[0]["ms"] if depth5 else "?"))

    heading(document, "3.4  Publishing", 2)
    para(document,
         "The game is packaged with **pygbag**, which runs CPython compiled to WebAssembly in the "
         "browser (pygbag build game). The web build was tested locally and uploaded to "
         "**itch.io** as an HTML5 project, giving a public link: %s. The source code is at %s." %
         (config.PUBLISHED_URL, config.REPO_URL))

    # ---------------- 4 Conclusion ----------------
    heading(document, "4  Conclusion")
    para(document,
         "The project delivers a complete, published two-player game of chance with an AI that "
         "does exactly what the brief describes: at every turn it evaluates every move, every "
         "possible die outcome and every reply, and picks the move with the highest expected "
         "value. Showing the odds and the AI's evaluation on screen makes the reasoning easy to "
         "follow, and the tests and %s experimental games give evidence that the AI works and "
         "improves with depth." % "{:,}".format(games_each * len(results)))
    para(document,
         "**Limitations:** pure-Python search limits depth to about 4 plies, and the heuristic "
         "weights were tuned by hand. At this wind strength, modelling the dice did not "
         "measurably improve results over plain Minimax. **Future work:** Star1/Star2 pruning "
         "for chance nodes (Ballard, 1983) to search deeper; a Monte Carlo Tree Search agent for "
         "comparison; learning the heuristic weights by self-play; a stronger-wind option, which "
         "should make chance-aware play matter more; and online multiplayer and sound.")

    heading(document, "References", 2)
    for reference in [
            "Ballard, B.W. (1983) 'The *-minimax search procedure for trees containing chance "
            "nodes', Artificial Intelligence, 21(3), pp. 327-350.",
            "Russell, S. and Norvig, P. (2021) Artificial Intelligence: A Modern Approach. 4th edn. "
            "Pearson. Chapter 5: Adversarial Search and Games.",
            "Pygame Community (2024) Pygame documentation. Available at: https://www.pygame.org/docs/",
            "pygame-web (2024) pygbag: Python and Pygame in WebAssembly. Available at: "
            "https://github.com/pygame-web/pygbag"]:
        paragraph = document.add_paragraph(reference)
        paragraph.paragraph_format.space_after = Pt(2)
        for run in paragraph.runs:
            run.font.size = Pt(9)

    os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)
    document.save(OUTPUT)
    print("saved", OUTPUT)


if __name__ == "__main__":
    build()
