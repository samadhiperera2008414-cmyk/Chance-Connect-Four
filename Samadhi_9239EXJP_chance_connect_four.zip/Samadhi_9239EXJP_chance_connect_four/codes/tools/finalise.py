# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  finalise.py
#  One command to put your details everywhere and rebuild every
#  deliverable:
#    * writes name / ID / links into game/config.py and every file header
#    * re-runs the unit tests
#    * re-takes the screenshots (so the name shows in them)
#    * rebuilds the slides (PPTX) and the report (DOCX + PDF)
#    * rebuilds the web version and the itch.io upload zip
#    * zips the source code for submission
#
#  Usage (from the project folder):
#    python tools/finalise.py --name "Jane Doe" --id 12345678 \
#        --itch https://janedoe.itch.io/chance-connect-four \
#        --repo https://github.com/janedoe/chance-connect-four
#  Any option left out keeps its current value.
# =====================================================================

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
PYTHON = sys.executable


# ---------------------------------------------------------------------
# read_config_value - reads one string setting from game/config.py.
# Parameters: key - the setting name, e.g. "STUDENT_NAME"
# Returns: its current value
# ---------------------------------------------------------------------
def read_config_value(key):
    text = open(os.path.join(ROOT, "game", "config.py")).read()
    return re.search(r'^%s = "(.*)"' % key, text, re.M).group(1)


# ---------------------------------------------------------------------
# update_config - writes new values into game/config.py.
# Parameters: values - dict {SETTING_NAME: new value}
# ---------------------------------------------------------------------
def update_config(values):
    path = os.path.join(ROOT, "game", "config.py")
    text = open(path).read()
    for key, value in values.items():
        text = re.sub(r'^%s = ".*"' % key, '%s = "%s"' % (key, value), text, flags=re.M)
    open(path, "w").write(text)


# ---------------------------------------------------------------------
# update_headers - replaces the name / ID lines in every .py file header.
# Parameters: name, student_id - the new details
# ---------------------------------------------------------------------
def update_headers(name, student_id):
    for path in glob.glob(os.path.join(ROOT, "game", "*.py")) + \
            glob.glob(os.path.join(ROOT, "tools", "*.py")):
        text = open(path).read()
        text = re.sub(r"^#  Student Name : .*$", "#  Student Name : %s" % name, text, flags=re.M)
        text = re.sub(r"^#  Student ID   : .*$", "#  Student ID   : %s" % student_id, text,
                      flags=re.M)
        open(path, "w").write(text)
    readme = os.path.join(ROOT, "README.md")
    text = open(readme).read()
    text = re.sub(r"^Student: .* · ID: .*$", "Student: %s · ID: %s" % (name, student_id), text,
                  flags=re.M)
    open(readme, "w").write(text)


# ---------------------------------------------------------------------
# run - runs a project script and stops if it fails.
# Parameters: arguments - list of command-line arguments
# ---------------------------------------------------------------------
def run(arguments):
    print(">>", " ".join(arguments))
    subprocess.run(arguments, cwd=ROOT, check=True)


# ---------------------------------------------------------------------
# zip_folder - zips files into an archive.
# Parameters:
#   archive_path - the .zip to create
#   files        - list of (path on disk, path inside the zip)
# ---------------------------------------------------------------------
def zip_folder(archive_path, files):
    os.makedirs(os.path.dirname(archive_path), exist_ok=True)
    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for disk_path, archive_name in files:
            archive.write(disk_path, archive_name)
    print("saved", archive_path)


# ---------------------------------------------------------------------
# source_files - lists the files that belong in the source-code zip.
# Parameters: none.  Returns: list of (disk path, name inside zip)
# ---------------------------------------------------------------------
def source_files():
    files = []
    for folder in ("game", "tools", "results"):
        for path in sorted(glob.glob(os.path.join(ROOT, folder, "**", "*"), recursive=True)):
            relative = os.path.relpath(path, ROOT)
            if os.path.isfile(path) and "build" not in relative.split(os.sep) \
                    and "__pycache__" not in relative:
                files.append((path, os.path.join("ChanceConnectFour", relative)))
    for name in ("README.md", "requirements.txt"):
        files.append((os.path.join(ROOT, name), os.path.join("ChanceConnectFour", name)))
    return files


# ---------------------------------------------------------------------
# main - parses the options and rebuilds everything.
# Parameters: none
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Set student details and rebuild deliverables")
    parser.add_argument("--name")
    parser.add_argument("--id")
    parser.add_argument("--itch")
    parser.add_argument("--repo")
    parser.add_argument("--skip-web", action="store_true", help="do not rebuild the web version")
    options = parser.parse_args()

    values = {}
    if options.name:
        values["STUDENT_NAME"] = options.name
    if options.id:
        values["STUDENT_ID"] = options.id
    if options.itch:
        values["PUBLISHED_URL"] = options.itch
    if options.repo:
        values["REPO_URL"] = options.repo
    update_config(values)
    name, student_id = read_config_value("STUDENT_NAME"), read_config_value("STUDENT_ID")
    update_headers(name, student_id)
    file_title = "%s_ChanceConnectFour" % name.replace(" ", "")

    run([PYTHON, "tools/test_game.py"])
    run([PYTHON, "tools/take_screenshots.py"])
    run([PYTHON, "tools/draw_figures.py"])

    # Remove old generated decks/reports so only the current name remains
    for pattern in ("slides/*_ChanceConnectFour.pptx", "report/*_ChanceConnectFour.*"):
        for old in glob.glob(os.path.join(ROOT, pattern)):
            os.remove(old)
    run([PYTHON, "tools/build_slides.py"])
    run([PYTHON, "tools/build_report.py"])
    soffice = shutil.which("soffice") or "/Applications/LibreOffice.app/Contents/MacOS/soffice"
    if os.path.exists(soffice):
        subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir",
                        os.path.join(ROOT, "report"),
                        os.path.join(ROOT, "report", file_title + ".docx")],
                       check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    if not options.skip_web:
        run([PYTHON, "-m", "pygbag", "--build", "--title", "Chance Connect Four", "game"])
        web = os.path.join(ROOT, "game", "build", "web")
        zip_folder(os.path.join(ROOT, "publish", "ChanceConnectFour_itchio_upload.zip"),
                   [(os.path.join(web, f), f) for f in os.listdir(web)])

    for old in glob.glob(os.path.join(ROOT, "submission", "*_source.zip")):
        os.remove(old)
    zip_folder(os.path.join(ROOT, "submission", file_title + "_source.zip"), source_files())
    print("\nDone. Deliverables:\n  slides/%s.pptx\n  report/%s.docx (+ .pdf)\n"
          "  publish/ChanceConnectFour_itchio_upload.zip\n  submission/%s_source.zip"
          % (file_title, file_title, file_title))


if __name__ == "__main__":
    main()
