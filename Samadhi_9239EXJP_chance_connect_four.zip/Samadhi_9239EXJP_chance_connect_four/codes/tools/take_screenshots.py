# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  take_screenshots.py
#  Runs the real game without a window and saves screenshots of the
#  main screens to backup/screenshots (backup for the live demo, and
#  pictures for the slides and report).
#  Run from the project folder:   python tools/take_screenshots.py
# =====================================================================

import os
import random
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"          # no real window needed
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "game"))

import pygame          # noqa: E402
import board as rules  # noqa: E402
import config          # noqa: E402
import main            # noqa: E402

OUTPUT = os.path.join(HERE, "..", "backup", "screenshots")


# ---------------------------------------------------------------------
# save
# Draws the game and writes the screen to a PNG file.
# Parameters:
#   game - the main.Game object
#   name - file name without extension
# ---------------------------------------------------------------------
def save(game, name):
    game.draw()
    path = os.path.join(OUTPUT, name + ".png")
    pygame.image.save(game.screen, path)
    print("saved", path)


# ---------------------------------------------------------------------
# run_frames
# Advances the game by a number of 1/60 s frames.
# Parameters:
#   game   - the main.Game object
#   frames - how many frames to run
# ---------------------------------------------------------------------
def run_frames(game, frames):
    for _ in range(frames):
        game.update(1 / 60)


# ---------------------------------------------------------------------
# play_until
# Lets the game run (AI moves + animations) until a condition is met.
# Parameters:
#   game      - the main.Game object
#   condition - function(game) -> bool
#   limit     - maximum number of frames to run
# ---------------------------------------------------------------------
def play_until(game, condition, limit=20000):
    for _ in range(limit):
        if condition(game):
            return True
        game.update(1 / 60)
    return False


# ---------------------------------------------------------------------
# main
# Produces each screenshot in turn.
# Parameters: none
# ---------------------------------------------------------------------
def run():
    os.makedirs(OUTPUT, exist_ok=True)
    pygame.init()
    screen = pygame.display.set_mode((config.WINDOW_WIDTH, config.WINDOW_HEIGHT))
    game = main.Game(screen)
    game.rng = random.Random(4)

    # 1. Title screen
    game.time = 0.8
    pygame.mouse.get_pos = lambda: (700, 400)     # hover the "Hard" button
    save(game, "01_menu")

    # 2. Human vs Hard AI - a few moves in, hovering a column
    game.start_match("pvai", "Hard")
    for column in (3, 3, 2, 4):
        game.begin_move(column)
        play_until(game, lambda g: g.state == "turn")
        play_until(game, lambda g: g.state in ("turn", "game_over") and not g.is_ai_turn())
    pygame.mouse.get_pos = lambda: (main.column_centre_x(1), 300)
    save(game, "02_human_turn_with_odds")

    # 3. A gust in action: force a "6" roll and capture mid-drift
    game.rng = random.Random(0)
    while True:
        game.begin_move(1)
        if game.move["drift"] != 0 and game.move["landing"] != game.move["aimed"]:
            break
        game.state, game.move = "turn", None
    run_frames(game, int((main.DIE_ROLL_TIME + main.DIE_SHOW_TIME) * 60) + 9)
    save(game, "03_wind_gust")

    # 4. Play on to the end: AI vs AI so a full game is shown
    game.start_match("aivai", None)
    game.rng = random.Random(11)
    play_until(game, lambda g: g.state == "game_over")
    game.time = 0.3
    save(game, "04_game_over")

    # 5. AI analysis during an AI vs AI game, mid-game
    game.start_match("aivai", None)
    game.rng = random.Random(3)
    play_until(game, lambda g: sum(cell != 0 for row in g.board for cell in row) >= 9
               and g.state == "turn")
    save(game, "05_ai_analysis")

    pygame.quit()


if __name__ == "__main__":
    run()
