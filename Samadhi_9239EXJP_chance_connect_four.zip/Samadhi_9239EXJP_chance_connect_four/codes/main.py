# =====================================================================
#  Chance Connect Four  -  5FTC2067 Artificial Intelligence Principles
#  Student Name : Samadhi Perera
#  Student ID   : 9239EXJP
#
#  main.py
#  The playable game: window, menus, drawing, animation and input.
#  Built with Pygame. The main loop is "async" so the same file runs on
#  the desktop AND in a web browser after packaging with pygbag.
#
#  Run on desktop :  python main.py
#  Build for web  :  pygbag game        (from the project folder)
# =====================================================================

import asyncio
import math
import random

import pygame

import ai
import board as rules
import config

# ---------------------------------------------------------------------
#  Colours (R, G, B)
# ---------------------------------------------------------------------
BACKGROUND = (15, 23, 42)
PANEL = (30, 41, 59)
PANEL_BORDER = (51, 65, 85)
BOARD_BLUE = (37, 99, 235)
BOARD_SHADOW = (23, 64, 160)
HOLE = (12, 18, 34)
TEXT = (241, 245, 249)
MUTED = (148, 163, 184)
ACCENT = (56, 189, 248)
GOOD = (34, 197, 94)
BAD = (248, 113, 113)
WHITE = (255, 255, 255)

PLAYER_COLOURS = {
    rules.PLAYER_ONE: (239, 68, 68),     # red
    rules.PLAYER_TWO: (250, 204, 21),    # yellow
}
PLAYER_COLOUR_NAMES = {rules.PLAYER_ONE: "Red", rules.PLAYER_TWO: "Yellow"}

# ---------------------------------------------------------------------
#  Layout (pixels)
# ---------------------------------------------------------------------
CELL_SIZE = 80
PIECE_RADIUS = 32
BOARD_LEFT = 50
BOARD_TOP = 190
BOARD_WIDTH = CELL_SIZE * rules.COLS
BOARD_HEIGHT = CELL_SIZE * rules.ROWS
HOVER_Y = 150                       # height of the piece held above the board
PANEL_LEFT = 650
PANEL_WIDTH = 280

# ---------------------------------------------------------------------
#  Animation timings (seconds)
# ---------------------------------------------------------------------
DIE_ROLL_TIME = 0.7          # die tumbles
DIE_SHOW_TIME = 0.45         # final face shown before the piece moves
DRIFT_TIME = 0.3             # sideways gust movement
GRAVITY = 3000               # falling speed-up (pixels / second^2)
AI_PAUSE = 0.45              # small pause so the AI does not move instantly

# Pip positions on a die face, as fractions of the die size
DIE_PIPS = {
    1: [(0.5, 0.5)],
    2: [(0.25, 0.25), (0.75, 0.75)],
    3: [(0.25, 0.25), (0.5, 0.5), (0.75, 0.75)],
    4: [(0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)],
    5: [(0.25, 0.25), (0.75, 0.25), (0.5, 0.5), (0.25, 0.75), (0.75, 0.75)],
    6: [(0.25, 0.25), (0.75, 0.25), (0.25, 0.5), (0.75, 0.5), (0.25, 0.75), (0.75, 0.75)],
}


# =====================================================================
#  Small drawing helpers
# =====================================================================

# ---------------------------------------------------------------------
# draw_text
# Draws a line of text anchored at a point.
# Parameters:
#   surface - the pygame Surface to draw on
#   text    - the string to draw
#   font    - the pygame Font to use
#   colour  - (R, G, B) text colour
#   position- (x, y) anchor point
#   anchor  - which point of the text sits on `position`
#             ("topleft", "center", "midtop", "midleft", "topright", ...)
# Returns: the pygame Rect the text occupies
# ---------------------------------------------------------------------
def draw_text(surface, text, font, colour, position, anchor="topleft"):
    image = font.render(text, True, colour)
    rect = image.get_rect(**{anchor: position})
    surface.blit(image, rect)
    return rect


# ---------------------------------------------------------------------
# draw_piece
# Draws one game piece with a simple 3D shine.
# Parameters:
#   surface - the pygame Surface to draw on
#   colour  - (R, G, B) main colour of the piece
#   centre  - (x, y) centre of the piece
#   radius  - radius in pixels
#   alpha   - 255 = solid, lower = see-through (used for the hover ghost)
# Returns: nothing
# ---------------------------------------------------------------------
def draw_piece(surface, colour, centre, radius=PIECE_RADIUS, alpha=255):
    size = radius * 2 + 4
    piece = pygame.Surface((size, size), pygame.SRCALPHA)
    middle = (size // 2, size // 2)
    darker = tuple(int(channel * 0.7) for channel in colour)
    lighter = tuple(min(255, int(channel * 1.15) + 20) for channel in colour)
    pygame.draw.circle(piece, darker + (alpha,), middle, radius)
    pygame.draw.circle(piece, colour + (alpha,), middle, radius - 4)
    pygame.draw.circle(piece, lighter + (alpha,), (middle[0] - radius // 4, middle[1] - radius // 4),
                       radius // 3)
    surface.blit(piece, (centre[0] - size // 2, centre[1] - size // 2))


# ---------------------------------------------------------------------
# draw_die
# Draws a die showing a face value.
# Parameters:
#   surface - the pygame Surface to draw on
#   face    - the number to show (1-6), or None for a blank die
#   rect    - pygame Rect where the die goes
#   tilt    - rotation in degrees (used while the die is rolling)
# Returns: nothing
# ---------------------------------------------------------------------
def draw_die(surface, face, rect, tilt=0):
    die = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(die, WHITE, die.get_rect(), border_radius=16)
    pygame.draw.rect(die, (203, 213, 225), die.get_rect(), width=3, border_radius=16)
    if face:
        # Faces 1 and 6 cause a gust, so their pips are drawn in the accent colour
        pip_colour = (37, 99, 235) if face in (1, 6) else (15, 23, 42)
        for fx, fy in DIE_PIPS[face]:
            pygame.draw.circle(die, pip_colour, (int(fx * rect.width), int(fy * rect.height)),
                               rect.width // 11)
    if tilt:
        die = pygame.transform.rotate(die, tilt)
    surface.blit(die, die.get_rect(center=rect.center))


# ---------------------------------------------------------------------
# column_centre_x
# Converts a column index to the x pixel of its centre.
# Parameters:
#   column - column index (0-6)
# Returns: x coordinate in pixels
# ---------------------------------------------------------------------
def column_centre_x(column):
    return BOARD_LEFT + column * CELL_SIZE + CELL_SIZE // 2


# ---------------------------------------------------------------------
# row_centre_y
# Converts a row index to the y pixel of its centre.
# Parameters:
#   row - row index (0 = top)
# Returns: y coordinate in pixels
# ---------------------------------------------------------------------
def row_centre_y(row):
    return BOARD_TOP + row * CELL_SIZE + CELL_SIZE // 2


# ---------------------------------------------------------------------
# column_at_pixel
# Finds which board column is under the mouse.
# Parameters:
#   x - mouse x coordinate in pixels
# Returns: a column index, or None if the mouse is not over the board
# ---------------------------------------------------------------------
def column_at_pixel(x):
    if BOARD_LEFT <= x < BOARD_LEFT + BOARD_WIDTH:
        return (x - BOARD_LEFT) // CELL_SIZE
    return None


# =====================================================================
#  Button
# =====================================================================
class Button:
    # -----------------------------------------------------------------
    # __init__
    # Creates a clickable button.
    # Parameters:
    #   rect     - pygame Rect for position and size
    #   label    - text shown on the button
    #   action   - value returned when the button is clicked
    #   subtitle - optional smaller text under the label
    # -----------------------------------------------------------------
    def __init__(self, rect, label, action, subtitle=""):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.action = action
        self.subtitle = subtitle

    # -----------------------------------------------------------------
    # draw
    # Draws the button, lighter when the mouse is over it.
    # Parameters:
    #   surface   - the pygame Surface to draw on
    #   fonts     - dictionary of fonts from the Game
    #   mouse_pos - current (x, y) of the mouse
    # -----------------------------------------------------------------
    def draw(self, surface, fonts, mouse_pos):
        hovered = self.rect.collidepoint(mouse_pos)
        fill = (51, 65, 85) if hovered else PANEL
        border = ACCENT if hovered else PANEL_BORDER
        pygame.draw.rect(surface, fill, self.rect, border_radius=12)
        pygame.draw.rect(surface, border, self.rect, width=2, border_radius=12)
        if self.subtitle:
            draw_text(surface, self.label, fonts["button"], TEXT,
                      (self.rect.left + 20, self.rect.top + 9))
            draw_text(surface, self.subtitle, fonts["small"], MUTED,
                      (self.rect.left + 20, self.rect.top + 36))
        else:
            draw_text(surface, self.label, fonts["button"], TEXT, self.rect.center, "center")

    # -----------------------------------------------------------------
    # is_clicked
    # Parameters:
    #   position - (x, y) of a mouse click
    # Returns: True if the click was inside the button
    # -----------------------------------------------------------------
    def is_clicked(self, position):
        return self.rect.collidepoint(position)


# =====================================================================
#  Game - holds all state and runs one frame at a time
#
#  States:
#    "menu"      title screen
#    "turn"      waiting for the current player to choose a column
#    "thinking"  the AI is searching for its move
#    "rolling"   the wind die is rolling
#    "moving"    the piece is drifting sideways and then falling
#    "game_over" someone won or the board is full
# =====================================================================
class Game:
    # -----------------------------------------------------------------
    # __init__
    # Sets up fonts, menu buttons and an empty match.
    # Parameters:
    #   screen - the pygame display Surface
    # -----------------------------------------------------------------
    def __init__(self, screen):
        self.screen = screen
        self.rng = random.Random()
        self.fonts = {
            "title": pygame.font.Font(None, 84),
            "heading": pygame.font.Font(None, 46),
            "big": pygame.font.Font(None, 40),
            "button": pygame.font.Font(None, 32),
            "body": pygame.font.Font(None, 27),
            "small": pygame.font.Font(None, 23),
            "tiny": pygame.font.Font(None, 20),
        }
        self.menu_buttons = self.create_menu_buttons()
        self.state = "menu"
        self.mode = None
        self.agents = {}
        self.player_names = {}
        self.scores = {rules.PLAYER_ONE: 0, rules.PLAYER_TWO: 0, "draws": 0}
        self.starting_player = rules.PLAYER_ONE
        self.time = 0.0
        self.reset_board()

    # -----------------------------------------------------------------
    # create_menu_buttons
    # Builds the buttons on the title screen.
    # Parameters: none
    # Returns: a list of Button objects
    # -----------------------------------------------------------------
    def create_menu_buttons(self):
        options = [
            ("Play vs AI  -  Easy", ("pvai", "Easy"), "AI looks 1 move ahead"),
            ("Play vs AI  -  Medium", ("pvai", "Medium"), "AI looks 2 moves ahead"),
            ("Play vs AI  -  Hard", ("pvai", "Hard"), "AI looks 4 moves ahead"),
            ("Two Players", ("pvp", None), "Take turns on the same screen"),
            ("Watch AI vs AI", ("aivai", None), "Medium (Red) vs Hard (Yellow)"),
        ]
        buttons = []
        for index, (label, action, subtitle) in enumerate(options):
            rect = (530, 205 + index * 82, 380, 66)
            buttons.append(Button(rect, label, action, subtitle))
        return buttons

    # -----------------------------------------------------------------
    # start_match
    # Starts a new series of games in the chosen mode.
    # Parameters:
    #   mode       - "pvai" (human vs AI), "pvp" (two humans) or "aivai"
    #   difficulty - "Easy"/"Medium"/"Hard" for pvai, otherwise None
    # -----------------------------------------------------------------
    def start_match(self, mode, difficulty):
        self.mode = mode
        self.scores = {rules.PLAYER_ONE: 0, rules.PLAYER_TWO: 0, "draws": 0}
        self.starting_player = rules.PLAYER_ONE
        if mode == "pvai":
            depth = config.DIFFICULTY_DEPTHS[difficulty]
            self.agents = {rules.PLAYER_TWO: ai.ExpectiminimaxAgent(depth)}
            self.player_names = {rules.PLAYER_ONE: "You",
                                 rules.PLAYER_TWO: "AI (%s)" % difficulty}
        elif mode == "pvp":
            self.agents = {}
            self.player_names = {rules.PLAYER_ONE: "Player 1", rules.PLAYER_TWO: "Player 2"}
        else:
            self.agents = {
                rules.PLAYER_ONE: ai.ExpectiminimaxAgent(config.DIFFICULTY_DEPTHS["Medium"]),
                rules.PLAYER_TWO: ai.ExpectiminimaxAgent(config.DIFFICULTY_DEPTHS["Hard"]),
            }
            self.player_names = {rules.PLAYER_ONE: "AI Medium", rules.PLAYER_TWO: "AI Hard"}
        self.reset_board()

    # -----------------------------------------------------------------
    # reset_board
    # Clears the board for a new game. The starting player alternates
    # each game so neither side always has the first-move advantage.
    # Parameters: none
    # -----------------------------------------------------------------
    def reset_board(self):
        self.board = rules.create_board()
        self.current_player = self.starting_player
        self.winner = None
        self.winning_cells = []
        self.die_face = None
        self.die_tilt = 0
        self.wind_message = "Choose a column, then the wind die decides!"
        self.last_search = None
        self.last_search_player = None
        self.move = None
        self.state_timer = 0.0
        self.thinking_frames = 0
        if self.mode is not None:
            self.state = "turn"

    # -----------------------------------------------------------------
    # is_ai_turn
    # Parameters: none
    # Returns: True if the current player is controlled by the computer
    # -----------------------------------------------------------------
    def is_ai_turn(self):
        return self.current_player in self.agents

    # =================================================================
    #  Input
    # =================================================================

    # -----------------------------------------------------------------
    # handle_event
    # Reacts to one pygame event (mouse click or key press).
    # Parameters:
    #   event - the pygame Event to handle
    # -----------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.handle_click(event.pos)
        elif event.type == pygame.KEYDOWN:
            self.handle_key(event.key)

    # -----------------------------------------------------------------
    # handle_click
    # Parameters:
    #   position - (x, y) of the mouse click
    # -----------------------------------------------------------------
    def handle_click(self, position):
        if self.state == "menu":
            for button in self.menu_buttons:
                if button.is_clicked(position):
                    self.start_match(*button.action)
        elif self.state == "game_over":
            self.starting_player = rules.get_other_player(self.starting_player)
            self.reset_board()
        elif self.state == "turn" and not self.is_ai_turn():
            column = column_at_pixel(position[0])
            if column is not None and rules.is_valid_column(self.board, column):
                self.begin_move(column)

    # -----------------------------------------------------------------
    # handle_key
    # Keys: 1-7 drop a piece, R restarts, M or Esc returns to the menu.
    # Parameters:
    #   key - the pygame key code that was pressed
    # -----------------------------------------------------------------
    def handle_key(self, key):
        if key in (pygame.K_m, pygame.K_ESCAPE):
            self.state = "menu"
            self.mode = None
        elif key == pygame.K_r and self.state != "menu":
            self.reset_board()
        elif self.state == "turn" and not self.is_ai_turn() and pygame.K_1 <= key <= pygame.K_7:
            column = key - pygame.K_1
            if rules.is_valid_column(self.board, column):
                self.begin_move(column)

    # =================================================================
    #  Game flow
    # =================================================================

    # -----------------------------------------------------------------
    # begin_move
    # The current player has aimed at a column: roll the wind die and
    # work out where the piece will really land.
    # Parameters:
    #   aimed_column - the column the player chose
    # -----------------------------------------------------------------
    def begin_move(self, aimed_column):
        face = rules.roll_wind_die(self.rng)
        drift = rules.DIE_FACE_TO_DRIFT[face]
        landing_column = rules.resolve_landing_column(self.board, aimed_column, drift)
        self.move = {
            "player": self.current_player,
            "aimed": aimed_column,
            "face": face,
            "drift": drift,
            "landing": landing_column,
            "row": rules.get_landing_row(self.board, landing_column),
            "x": float(column_centre_x(aimed_column)),
            "y": float(HOVER_Y),
            "speed": 0.0,
        }
        self.state = "rolling"
        self.state_timer = 0.0
        self.wind_message = "Rolling the wind die..."

    # -----------------------------------------------------------------
    # describe_wind
    # Builds the message explaining what the wind did.
    # Parameters:
    #   move - the move dictionary created in begin_move
    # Returns: a short description string
    # -----------------------------------------------------------------
    def describe_wind(self, move):
        aimed, landing = move["aimed"] + 1, move["landing"] + 1
        if move["drift"] == 0:
            return "Calm air - lands in column %d" % landing
        direction = "LEFT" if move["drift"] < 0 else "RIGHT"
        if landing == aimed:
            return "Gust %s, but blocked - stays in %d" % (direction, landing)
        return "Gust %s!  Column %d -> %d" % (direction, aimed, landing)

    # -----------------------------------------------------------------
    # finish_move
    # The piece has landed: update the board and check for a result.
    # Parameters: none
    # -----------------------------------------------------------------
    def finish_move(self):
        move = self.move
        rules.drop_piece(self.board, move["landing"], move["player"])
        self.move = None
        if rules.is_winning_placement(self.board, move["row"], move["landing"], move["player"]):
            self.winner = move["player"]
            self.winning_cells = rules.get_winning_cells(self.board, move["player"])
            self.scores[move["player"]] += 1
            self.state = "game_over"
        elif rules.is_board_full(self.board):
            self.winner = None
            self.scores["draws"] += 1
            self.state = "game_over"
        else:
            self.current_player = rules.get_other_player(self.current_player)
            self.state = "turn"
        self.state_timer = 0.0

    # -----------------------------------------------------------------
    # update
    # Advances timers and animations by one frame.
    # Parameters:
    #   dt - seconds since the previous frame
    # -----------------------------------------------------------------
    def update(self, dt):
        self.time += dt
        self.state_timer += dt

        if self.state == "turn" and self.is_ai_turn() and self.state_timer >= AI_PAUSE:
            # Switch to "thinking" first so the message is drawn before the search
            self.state = "thinking"
            self.thinking_frames = 0

        elif self.state == "thinking":
            self.thinking_frames += 1
            if self.thinking_frames >= 2:
                agent = self.agents[self.current_player]
                column = agent.choose_column(self.board, self.current_player, self.rng)
                self.last_search = agent.last_result
                self.last_search_player = self.current_player
                self.begin_move(column)

        elif self.state == "rolling":
            if self.state_timer < DIE_ROLL_TIME:
                # Show a new random face every few frames while tumbling
                if int(self.state_timer * 14) != int((self.state_timer - dt) * 14):
                    self.die_face = self.rng.randint(1, 6)
                self.die_tilt = math.sin(self.state_timer * 30) * 18
            else:
                self.die_face = self.move["face"]
                self.die_tilt = 0
                self.wind_message = self.describe_wind(self.move)
                if self.state_timer >= DIE_ROLL_TIME + DIE_SHOW_TIME:
                    self.state = "moving"
                    self.state_timer = 0.0

        elif self.state == "moving":
            self.update_falling_piece(dt)

    # -----------------------------------------------------------------
    # update_falling_piece
    # Moves the piece sideways (if the wind pushed it) and then drops it.
    # Parameters:
    #   dt - seconds since the previous frame
    # -----------------------------------------------------------------
    def update_falling_piece(self, dt):
        move = self.move
        start_x = column_centre_x(move["aimed"])
        end_x = column_centre_x(move["landing"])
        if start_x != end_x and self.state_timer < DRIFT_TIME:
            progress = self.state_timer / DRIFT_TIME
            eased = 1 - (1 - progress) ** 3                # ease-out curve
            move["x"] = start_x + (end_x - start_x) * eased
            return
        move["x"] = end_x
        move["speed"] += GRAVITY * dt
        move["y"] += move["speed"] * dt
        if move["y"] >= row_centre_y(move["row"]):
            self.finish_move()

    # =================================================================
    #  Drawing
    # =================================================================

    # -----------------------------------------------------------------
    # draw
    # Draws the whole screen for the current state.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw(self):
        self.screen.fill(BACKGROUND)
        if self.state == "menu":
            self.draw_menu()
        else:
            self.draw_header()
            self.draw_hover_preview()
            self.draw_moving_piece()
            self.draw_board()
            self.draw_side_panel()
            if self.state == "game_over":
                self.draw_game_over_banner()

    # -----------------------------------------------------------------
    # draw_menu
    # Title screen with the rules on the left and mode buttons on the right.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_menu(self):
        screen = self.screen
        draw_text(screen, config.GAME_TITLE.upper(), self.fonts["title"], TEXT, (480, 70), "center")
        draw_text(screen, "Connect Four where the wind has a say - with an Expectiminimax AI",
                  self.fonts["body"], ACCENT, (480, 122), "center")

        # Small row of decorative pieces
        for index in range(7):
            colour = PLAYER_COLOURS[rules.PLAYER_ONE if index % 2 == 0 else rules.PLAYER_TWO]
            bob = math.sin(self.time * 2 + index * 0.6) * 4
            draw_piece(screen, colour, (330 + index * 50, 165 + bob), 16)

        # Rules card
        rules_rect = pygame.Rect(50, 205, 440, 394)
        pygame.draw.rect(screen, PANEL, rules_rect, border_radius=16)
        pygame.draw.rect(screen, PANEL_BORDER, rules_rect, width=2, border_radius=16)
        draw_text(screen, "How to play", self.fonts["big"], TEXT, (75, 225))
        lines = [
            "1. Pick a column to drop your piece.",
            "2. Roll the WIND DIE:",
            "      1        gust blows it 1 column LEFT",
            "      2 - 5   calm, lands where you aimed",
            "      6        gust blows it 1 column RIGHT",
            "3. Blocked gusts (edge / full column)",
            "    leave the piece where you aimed.",
            "4. Connect 4 in a row to win!",
            "",
            "The AI looks at every column, every die",
            "roll and every reply, then picks the move",
            "with the best EXPECTED outcome.",
        ]
        for index, line in enumerate(lines):
            colour = MUTED if index >= 9 else TEXT
            draw_text(screen, line, self.fonts["small"], colour, (75, 275 + index * 25))
        draw_die(screen, 1, pygame.Rect(390, 300, 34, 34))
        draw_die(screen, 6, pygame.Rect(430, 300, 34, 34))

        mouse = pygame.mouse.get_pos()
        for button in self.menu_buttons:
            button.draw(screen, self.fonts, mouse)

        draw_text(screen, "%s   |   ID: %s   |   5FTC2067 AI Principles" %
                  (config.STUDENT_NAME, config.STUDENT_ID),
                  self.fonts["small"], MUTED, (480, 690), "center")

    # -----------------------------------------------------------------
    # draw_header
    # Title bar at the top of the game screen.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_header(self):
        draw_text(self.screen, config.GAME_TITLE, self.fonts["heading"], TEXT, (50, 28))
        draw_text(self.screen, "%s  |  %s" % (config.STUDENT_NAME, config.STUDENT_ID),
                  self.fonts["small"], MUTED, (930, 30), "topright")
        draw_text(self.screen, "R restart   M menu", self.fonts["tiny"], MUTED,
                  (930, 54), "topright")
        pygame.draw.line(self.screen, PANEL_BORDER, (50, 80), (930, 80), 2)

    # -----------------------------------------------------------------
    # draw_board
    # Draws the blue board, the placed pieces and the winning line.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_board(self):
        board_rect = pygame.Rect(BOARD_LEFT, BOARD_TOP, BOARD_WIDTH, BOARD_HEIGHT)
        shadow_rect = board_rect.move(0, 8)
        pygame.draw.rect(self.screen, BOARD_SHADOW, shadow_rect, border_radius=18)
        pygame.draw.rect(self.screen, BOARD_BLUE, board_rect, border_radius=18)

        for row in range(rules.ROWS):
            for column in range(rules.COLS):
                centre = (column_centre_x(column), row_centre_y(row))
                cell = self.board[row][column]
                if cell == rules.EMPTY:
                    pygame.draw.circle(self.screen, HOLE, centre, PIECE_RADIUS)
                else:
                    draw_piece(self.screen, PLAYER_COLOURS[cell], centre)

        # Pulsing ring around the winning four
        if self.winning_cells:
            pulse = 3 + int(2 * (1 + math.sin(self.time * 6)))
            for row, column in self.winning_cells:
                pygame.draw.circle(self.screen, WHITE,
                                   (column_centre_x(column), row_centre_y(row)),
                                   PIECE_RADIUS + 2, pulse)

        for column in range(rules.COLS):
            draw_text(self.screen, str(column + 1), self.fonts["small"], MUTED,
                      (column_centre_x(column), BOARD_TOP + BOARD_HEIGHT + 22), "center")

    # -----------------------------------------------------------------
    # draw_hover_preview
    # For a human turn: shows a see-through piece over the hovered column
    # and the chance (%) of landing in each column because of the wind.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_hover_preview(self):
        if self.state != "turn" or self.is_ai_turn():
            if self.state in ("turn", "thinking"):
                text = "%s is thinking..." % self.player_names[self.current_player]
                draw_text(self.screen, text, self.fonts["body"], MUTED,
                          (BOARD_LEFT + BOARD_WIDTH // 2, HOVER_Y), "center")
            return
        column = column_at_pixel(pygame.mouse.get_pos()[0])
        if column is None or not rules.is_valid_column(self.board, column):
            draw_text(self.screen, "%s: click a column" % self.player_names[self.current_player],
                      self.fonts["body"], MUTED, (BOARD_LEFT + BOARD_WIDTH // 2, HOVER_Y), "center")
            return
        colour = PLAYER_COLOURS[self.current_player]
        draw_piece(self.screen, colour, (column_centre_x(column), HOVER_Y), alpha=150)
        for landing, probability in rules.get_chance_outcomes(self.board, column):
            draw_text(self.screen, "%d%%" % round(probability * 100), self.fonts["small"],
                      colour, (column_centre_x(landing), 104), "center")

    # -----------------------------------------------------------------
    # draw_moving_piece
    # Draws the piece that is currently being blown / falling.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_moving_piece(self):
        if self.move and self.state in ("rolling", "moving"):
            centre = (int(self.move["x"]), int(self.move["y"]))
            draw_piece(self.screen, PLAYER_COLOURS[self.move["player"]], centre)
            # Wind streaks while the piece is being pushed sideways
            if self.state == "moving" and self.move["aimed"] != self.move["landing"] \
                    and self.state_timer < DRIFT_TIME:
                direction = 1 if self.move["drift"] > 0 else -1
                for offset in (-14, 0, 14):
                    start = (centre[0] - direction * 70, centre[1] + offset)
                    end = (centre[0] - direction * 42, centre[1] + offset)
                    pygame.draw.line(self.screen, ACCENT, start, end, 3)

    # -----------------------------------------------------------------
    # draw_card
    # Draws an empty rounded panel with a heading.
    # Parameters:
    #   rect  - pygame Rect of the card
    #   title - heading text at the top of the card
    # -----------------------------------------------------------------
    def draw_card(self, rect, title):
        pygame.draw.rect(self.screen, PANEL, rect, border_radius=14)
        pygame.draw.rect(self.screen, PANEL_BORDER, rect, width=2, border_radius=14)
        draw_text(self.screen, title, self.fonts["tiny"], MUTED, (rect.left + 16, rect.top + 12))

    # -----------------------------------------------------------------
    # draw_side_panel
    # Right-hand panel: players and score, wind die, AI analysis.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_side_panel(self):
        screen = self.screen

        # ---- Players and score ----
        card = pygame.Rect(PANEL_LEFT, 96, PANEL_WIDTH, 118)
        self.draw_card(card, "PLAYERS")
        draw_text(screen, "WINS", self.fonts["tiny"], MUTED, (card.right - 16, card.top + 12), "topright")
        for index, player in enumerate((rules.PLAYER_ONE, rules.PLAYER_TWO)):
            y = card.top + 48 + index * 34
            is_turn = player == self.current_player and self.state != "game_over"
            if is_turn:
                pygame.draw.rect(screen, (51, 65, 85), (card.left + 8, y - 15, PANEL_WIDTH - 16, 30),
                                 border_radius=8)
            draw_piece(screen, PLAYER_COLOURS[player], (card.left + 30, y), 11)
            draw_text(screen, self.player_names[player], self.fonts["body"],
                      TEXT if is_turn else MUTED, (card.left + 50, y), "midleft")
            draw_text(screen, str(self.scores[player]), self.fonts["body"], TEXT,
                      (card.right - 20, y), "midright")
        draw_text(screen, "Draws: %d" % self.scores["draws"], self.fonts["tiny"], MUTED,
                  (card.right - 20, card.bottom - 12), "bottomright")

        # ---- Wind die ----
        card = pygame.Rect(PANEL_LEFT, 228, PANEL_WIDTH, 176)
        self.draw_card(card, "WIND DIE")
        draw_die(screen, self.die_face, pygame.Rect(card.centerx - 42, card.top + 36, 84, 84),
                 self.die_tilt)
        draw_text(screen, "1 = left   2-5 = calm   6 = right", self.fonts["tiny"], MUTED,
                  (card.centerx, card.top + 136), "center")
        draw_text(screen, self.wind_message, self.fonts["small"], ACCENT,
                  (card.centerx, card.top + 158), "center")

        # ---- AI analysis ----
        card = pygame.Rect(PANEL_LEFT, 418, PANEL_WIDTH, 270)
        self.draw_card(card, "AI ANALYSIS - taller = closer to victory")
        self.draw_ai_analysis(card)

    # -----------------------------------------------------------------
    # draw_ai_analysis
    # Bar chart of the expected value the AI calculated for each column
    # on its last move. Bars are scaled between the worst and the best
    # column, so the tallest bar is the move closest to victory.
    # Parameters:
    #   card - pygame Rect of the card to draw inside
    # -----------------------------------------------------------------
    def draw_ai_analysis(self, card):
        screen = self.screen
        result = self.last_search
        if result is None:
            message = "No AI moves yet" if self.agents else "AI is off in Two Player mode"
            draw_text(screen, message, self.fonts["small"], MUTED, card.center, "center")
            return

        chart_top = card.top + 40
        chart_height = 140
        baseline = chart_top + chart_height
        slot = (PANEL_WIDTH - 28) / rules.COLS
        lowest = min(result.column_scores.values())
        highest = max(result.column_scores.values())
        pygame.draw.line(screen, PANEL_BORDER, (card.left + 14, baseline),
                         (card.right - 14, baseline), 2)

        for column in range(rules.COLS):
            x = int(card.left + 14 + column * slot + slot * 0.18)
            width = int(slot * 0.64)
            if column in result.column_scores:
                value = result.column_scores[column]
                share = (value - lowest) / (highest - lowest) if highest > lowest else 1.0
                height = int(8 + share * (chart_height - 12))
                is_best = column == result.best_column
                bar = pygame.Rect(x, baseline - height, width, height)
                pygame.draw.rect(screen, GOOD if is_best else (71, 85, 105), bar, border_radius=4)
                if is_best:
                    pygame.draw.rect(screen, WHITE, bar.inflate(6, 6), width=2, border_radius=6)
            else:
                draw_text(screen, "full", self.fonts["tiny"], MUTED,
                          (x + width // 2, baseline - 10), "center")
            draw_text(screen, str(column + 1), self.fonts["tiny"],
                      WHITE if column == result.best_column else MUTED,
                      (x + width // 2, chart_top + chart_height + 10), "center")

        best_value = result.column_scores[result.best_column]
        mover = self.player_names.get(self.last_search_player, "AI")
        draw_text(screen, "%s chose column %d  (value %+.0f)" %
                  (mover, result.best_column + 1, best_value),
                  self.fonts["tiny"], TEXT, (card.centerx, card.bottom - 46), "center")
        draw_text(screen, "%s positions searched in %.2f s" %
                  ("{:,}".format(result.nodes_searched), result.seconds),
                  self.fonts["tiny"], MUTED, (card.centerx, card.bottom - 24), "center")

    # -----------------------------------------------------------------
    # draw_game_over_banner
    # Shows who won above the board.
    # Parameters: none
    # -----------------------------------------------------------------
    def draw_game_over_banner(self):
        if self.winner is None:
            text, colour = "It's a draw!", TEXT
        else:
            name = self.player_names[self.winner]
            text = "You win!" if name == "You" else "%s wins!" % name
            colour = PLAYER_COLOURS[self.winner]
        banner = pygame.Rect(BOARD_LEFT, 92, BOARD_WIDTH, 84)
        pygame.draw.rect(self.screen, PANEL, banner, border_radius=14)
        pygame.draw.rect(self.screen, colour, banner, width=3, border_radius=14)
        draw_text(self.screen, text, self.fonts["heading"], colour,
                  (banner.centerx, banner.top + 30), "center")
        draw_text(self.screen, "Click to play again   |   M for menu", self.fonts["small"], MUTED,
                  (banner.centerx, banner.top + 62), "center")


# ---------------------------------------------------------------------
# main
# Opens the window and runs the game loop. It is async and awaits
# asyncio.sleep(0) every frame, which lets the browser (pygbag) stay
# responsive; on the desktop it behaves like a normal loop.
# Parameters: none
# ---------------------------------------------------------------------
async def main():
    pygame.init()
    screen = pygame.display.set_mode((config.WINDOW_WIDTH, config.WINDOW_HEIGHT))
    pygame.display.set_caption("%s - %s (%s)" %
                               (config.GAME_TITLE, config.STUDENT_NAME, config.STUDENT_ID))
    clock = pygame.time.Clock()
    game = Game(screen)

    running = True
    while running:
        dt = min(clock.tick(config.FRAMES_PER_SECOND) / 1000.0, 0.05)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                game.handle_event(event)
        game.update(dt)
        game.draw()
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
